package org.qisystems.e_hotel_pos

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
