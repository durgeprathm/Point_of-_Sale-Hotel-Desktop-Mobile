package org.qisystems.retailerp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
