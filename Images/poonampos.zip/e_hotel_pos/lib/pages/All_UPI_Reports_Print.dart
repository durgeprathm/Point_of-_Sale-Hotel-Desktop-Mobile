import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:retailerp/models/Sales.dart';

class AllUPIReportPrint extends StatefulWidget {
  final int indexFetch;
  List<Sales> UPIList = new List();

  AllUPIReportPrint(this.indexFetch, this.UPIList);

  @override
  _AllUPIReportPrintState createState() =>
      _AllUPIReportPrintState(this.indexFetch, this.UPIList);
}

class _AllUPIReportPrintState extends State<AllUPIReportPrint> {
  final int indexFetch;
  List<Sales> UPIList = new List();

  _AllUPIReportPrintState(this.indexFetch, this.UPIList);

  final pdf = pw.Document();
  var imageProvider;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("All UPI Report"),
      ),
      body: PdfPreview(
        build: (format) => _generatePdf(format),
      ),
    );
  }

  Future<Uint8List> _generatePdf(PdfPageFormat format) async {
    pdf.addPage(
      pw.MultiPage(
        build: (context) => [
          pw.Column(
              mainAxisAlignment: pw.MainAxisAlignment.start,
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Text('Retail ERP'),
                pw.SizedBox(height: 5),
                pw.Table.fromTextArray(context: context, data: <List<String>>[
                  <String>[
                    'SN',
                    'Customer Name',
                    'Date',
                    'Discount',
                    'Total\nAmount',
                    'Mode'
                  ],
                  ...UPIList.map((data) => [
                    data.Salesid.toString(),
                    data.SalesCustomername,
                    data.SalesDate,
                    data.SalesDiscount,
                    data.SalesTotal,
                    data.SalesPaymentMode
                  ])
                ]),
              ])

        ],
      ),
    );

    return pdf.save();
  }

  DataRow getRow(int index) {
    return DataRow(cells: [
      DataCell(Text(UPIList[index].SalesIDs.toString())),
      DataCell(Text(UPIList[index].SalesCustomername)),
      DataCell(Text(UPIList[index].SalesDate)),
      DataCell(Text(UPIList[index].SalesTotal.toString())),
      DataCell(Text(UPIList[index].SalesPaymentMode.toString()))
    ]);
  }

  List<DataRow> getDataRowList() {
    List<DataRow> myTempDataRow = List();
    for (int i = 0; i < UPIList.length; i++) {
      myTempDataRow.add(getRow(i));
    }
    return myTempDataRow;
  }
}
