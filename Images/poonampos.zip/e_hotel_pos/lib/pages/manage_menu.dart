import 'package:datetime_picker_formfield/datetime_picker_formfield.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:intl/intl.dart';
import 'package:retailerp/Adpater/fetch_menuList.dart';
import 'package:retailerp/Adpater/pos_purchase_fetch.dart';
import 'package:retailerp/Adpater/pos_purchse_delete.dart';
import 'package:retailerp/helpers/database_helper.dart';
import 'package:retailerp/models/menu.dart';
import 'package:retailerp/pages/edit_menu_screen_new.dart';
import 'package:retailerp/pages/preview_menu.dart';
import 'package:retailerp/utils/const.dart';
import 'package:retailerp/utils/modal_progress_hud.dart';
import 'package:sqflite/sqflite.dart';

class ManageMenu extends StatefulWidget {
  @override
  _ManageMenuState createState() => _ManageMenuState();
}

class _ManageMenuState extends State<ManageMenu> {
  @override
  // DatabaseHelper databaseHelper = DatabaseHelper();
  List<Menu> menuList = [];
  List<Menu> searchMenuList = [];
  int count;
  final dateFormat = DateFormat("yyyy-MM-dd");
  final initialValue = DateTime.now();
  final _fromDatetext = TextEditingController();
  final _toDatetext = TextEditingController();
  DateTime fromValue = DateTime.now();
  DateTime toValue = DateTime.now();
  bool _fromDatevalidate = false;
  bool _toDatevalidate = false;
  int changedCount = 0;
  int savedCount = 0;
  bool autoValidate = false;
  bool showResetIcon = false;
  bool readOnly = false;
  bool Datetofromenable = false;

  TextEditingController searchController = TextEditingController();

  bool _showCircle = false;
  Icon actionIcon = Icon(
    Icons.search,
    color: Colors.white,
  );
  Widget appBarTitle = Text("Manage Menu");

  @override
  void initState() {
    // ShowMenudetails();
    _getMenu();
  }

  //-------------------------------------------
  static const int kTabletBreakpoint = 552;

  @override
  Widget build(BuildContext context) {
    Widget content;
    var shortestSide = MediaQuery.of(context).size.shortestSide;
    print(shortestSide);
    if (shortestSide < kTabletBreakpoint) {
      content = _buildMobileManageMenu();
    } else {
      content = _buildTabletManageMenu();
    }

    return content;
  }

//-------------------------------------------
//---------------Tablet Mode Start-------------//
  Widget _buildTabletManageMenu() {
    // void handleClick(String value) {
    //   switch (value) {
    //     case 'Add Menu':
    //       Navigator.push(
    //           context, MaterialPageRoute(builder: (context) => AddMenu()));
    //       break;
    //     case 'Import Sales':
    //       Navigator.push(context,
    //           MaterialPageRoute(builder: (context) => ImportMenu()));
    //       break;
    //     case 'Add Supplier':
    //       Navigator.push(context,
    //           MaterialPageRoute(builder: (context) => AddSupplierDetails()));
    //       break;
    //     case 'Manage Suppliers':
    //       Navigator.push(context,
    //           MaterialPageRoute(builder: (context) => ManageSuppliers()));
    //       break;
    //   }
    // }

    var tabletWidth = MediaQuery.of(context).size.width * 0.20;
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Row(
          children: [
            FaIcon(FontAwesomeIcons.shoppingBag),
            SizedBox(
              width: 20.0,
            ),
            Text('Manage Menu'),
          ],
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.home, color: Colors.white),
            onPressed: () {
              Navigator.popUntil(
                  context, ModalRoute.withName(Navigator.defaultRouteName));
            },
          ),
          // PopupMenuButton<String>(
          //   onSelected: handleClick,
          //   itemBuilder: (BuildContext context) {
          //     return {
          //       'Add Menu',
          //       'Import Menu',
          //       'Add Supplier',
          //       'Manage Suppliers',
          //     }.map((String choice) {
          //       return PopupMenuItem<String>(
          //         value: choice,
          //         child: Text(choice),
          //       );
          //     }).toList();
          //   },
          // ),
        ],
      ),
      body: SafeArea(
        child: ModalProgressHUD(
          inAsyncCall: _showCircle,
          child: Column(
            children: [
              SizedBox(height: 10,),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Container(
                      width: tabletWidth,
                      height: 40,
                      child: TextField(
                        controller: searchController,
                        style: TextStyle(
                          color: Colors.blueGrey,
                        ),
                        decoration: InputDecoration(
                            hintText: "Start typing here..",
                            suffixIcon: IconButton(
                              icon: Icon(Icons.search),
                              color: PrimaryColor,
                              onPressed: () {},
                            )),
                      ),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Container(
                      height: 40,
                      width: tabletWidth,
                      child: DateTimeField(
                        controller: _fromDatetext,
                        format: dateFormat,
                        keyboardType: TextInputType.number,
                        onShowPicker: (context, currentValue) {
                          return showDatePicker(
                              context: context,
                              firstDate: DateTime(1900),
                              initialDate: currentValue ?? DateTime.now(),
                              lastDate: DateTime(2100));
                        },
                        autovalidate: autoValidate,
                        validator: (date) =>
                            date == null ? 'Invalid date' : null,
                        onChanged: (date) => setState(() {
                          fromValue = date;
                          print('Selected Date: ${date}');
                        }),
                        onSaved: (date) => setState(() {
                          fromValue = date;
                          print('Selected value Date: $fromValue');
                          savedCount++;
                        }),
                        resetIcon: showResetIcon ? Icon(Icons.delete) : null,
                        readOnly: readOnly,
                        decoration: InputDecoration(
                          border: OutlineInputBorder(),
                          labelText: 'From Date',
                          errorText:
                              _fromDatevalidate ? 'Enter From Date' : null,
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Container(
                      height: 40,
                      width: tabletWidth,
                      child: DateTimeField(
                        controller: _toDatetext,
                        format: dateFormat,
                        keyboardType: TextInputType.number,
                        onShowPicker: (context, currentValue) {
                          return showDatePicker(
                              context: context,
                              firstDate: DateTime(1900),
                              initialDate: currentValue ?? DateTime.now(),
                              lastDate: DateTime(2100));
                        },
                        autovalidate: autoValidate,
                        validator: (date) =>
                            date == null ? 'Invalid date' : null,
                        onChanged: (date) => setState(() {
                          toValue = date;
                          print('Selected Date: ${toValue}');
                        }),
                        onSaved: (date) => setState(() {
                          toValue = date;
                          print('Selected value Date: $_toDatetext');
                          savedCount++;
                        }),
                        resetIcon: showResetIcon ? Icon(Icons.delete) : null,
                        readOnly: readOnly,
                        decoration: InputDecoration(
                          border: OutlineInputBorder(),
                          labelText: 'To Date',
                          errorText: _toDatevalidate ? 'Enter Menu Date' : null,
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Container(
                      height: 40,
                      child: Material(
                        elevation: 5.0,
                        color: PrimaryColor,
                        borderRadius: BorderRadius.circular(10.0),
                        child: MaterialButton(
                          onPressed: () async {
                            setState(() {
                              _fromDatetext.text.isEmpty
                                  ? _fromDatevalidate = true
                                  : _fromDatevalidate = false;
                              _toDatetext.text.isEmpty
                                  ? _toDatevalidate = true
                                  : _toDatevalidate = false;

                              int dateDiff =
                                  toValue.difference(fromValue).inDays;
                              print('Date: $dateDiff');
                              if (dateDiff >= 0) {
                                setState(() {
                                  _showCircle = true;
                                });
                              } else {
                                Fluttertoast.showToast(
                                  msg:
                                      "Select from date must be less than to date!!!",
                                  toastLength: Toast.LENGTH_SHORT,
                                  backgroundColor: Colors.black38,
                                  textColor: Color(0xffffffff),
                                  gravity: ToastGravity.BOTTOM,
                                );
                              }
                            });
                            CircularProgressIndicator();
                            // _toDatetext.clear();
                          },
                          minWidth: 75,
                          child: Padding(
                            padding: const EdgeInsets.all(5.0),
                            child: Text(
                              "Go",
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                                fontSize: 18.0,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Divider(),
              Expanded(
                child: SingleChildScrollView(
                  child: Container(
                    child: Center(
                        child: DataTable(
                      columns: [
                        DataColumn(
                            label: Expanded(
                          child: Container(
                            child: Text('Sr No',
                                style: TextStyle(
                                    fontSize: 20, fontWeight: FontWeight.bold)),
                          ),
                        )),
                        DataColumn(
                            label: Expanded(
                          child: Container(
                            width: 200,
                            child: Text('Menu Name',
                                style: TextStyle(
                                    fontSize: 20, fontWeight: FontWeight.bold)),
                          ),
                        )),
                        DataColumn(
                            label: Expanded(
                          child: Container(
                            child: Text('Category',
                                style: TextStyle(
                                    fontSize: 20, fontWeight: FontWeight.bold)),
                          ),
                        )),
                        DataColumn(
                            label: Expanded(
                          child: Container(
                            child: Text('Total',
                                style: TextStyle(
                                    fontSize: 20, fontWeight: FontWeight.bold)),
                          ),
                        )),
                        DataColumn(
                            label: Expanded(
                          child: Container(
                            width: 50,
                            child: Text('Action',
                                style: TextStyle(
                                    fontSize: 20, fontWeight: FontWeight.bold)),
                          ),
                        )),
                      ],
                      rows: getDataRowList()
                    )),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

//---------------Tablet Mode End-------------//
//---------------Mobile Mode Start-------------//
  Widget _buildMobileManageMenu() {
    // void handleClick(String value) {
    //   switch (value) {
    //     case 'Add Menu':
    //       Navigator.push(
    //           context, MaterialPageRoute(builder: (context) => AddMenu()));
    //       break;
    //     case 'Import Sales':
    //       Navigator.push(context,
    //           MaterialPageRoute(builder: (context) => ImportMenu()));
    //       break;
    //     case 'Add Supplier':
    //       Navigator.push(context,
    //           MaterialPageRoute(builder: (context) => AddSupplierDetails()));
    //       break;
    //     case 'Manage Suppliers':
    //       Navigator.push(context,
    //           MaterialPageRoute(builder: (context) => ManageSuppliers()));
    //       break;
    //   }
    // }

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: appBarTitle,
        actions: [
          Row(
            children: [
              IconButton(
                icon: actionIcon,
                onPressed: () {
                  setState(() {
                    if (actionIcon.icon == Icons.search) {
                      actionIcon = new Icon(
                        Icons.close,
                        color: Colors.white,
                      );
                      appBarTitle = TextField(
                        controller: searchController,
                        style: TextStyle(
                          color: Colors.white,
                        ),
                        decoration: InputDecoration(
                            prefixIcon:
                                new Icon(Icons.search, color: Colors.white),
                            hintText: "Search...",
                            hintStyle: TextStyle(color: Colors.white)),
                      );
                    } else {
                      actionIcon = new Icon(
                        Icons.search,
                        color: Colors.white,
                      );
                      appBarTitle = new Text(
                        "Manage Menu",
                        style: TextStyle(
                          color: Colors.white,
                        ),
                      );
                      searchController.clear();
                    }
                  });
                },
              ),
              IconButton(
                icon: Icon(Icons.home, color: Colors.white),
                onPressed: () {
                  Navigator.popUntil(
                      context, ModalRoute.withName(Navigator.defaultRouteName));
                },
              ),
            ],
          ),
          // PopupMenuButton<String>(
          //   onSelected: handleClick,
          //   itemBuilder: (BuildContext context) {
          //     return {
          //       'Add Menu',
          //       'Import Menu',
          //       'Add Supplier',
          //       'Manage Suppliers',
          //     }.map((String choice) {
          //       return PopupMenuItem<String>(
          //         value: choice,
          //         child: Text(choice),
          //       );
          //     }).toList();
          //   },
          // ),
        ],
      ),
      body: SafeArea(
        child: ModalProgressHUD(
          inAsyncCall: _showCircle,
          child: Column(
            children: [
              Expanded(
                child: Container(
                  child: GestureDetector(
                    child: ListView.builder(
                        shrinkWrap: true,
                        scrollDirection: Axis.vertical,
                        itemCount: searchMenuList.length,
                        itemBuilder: (context, index) {
                          return Padding(
                            padding: const EdgeInsets.symmetric(
                                vertical: 3, horizontal: 8),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        Text("Menu Name: ",
                                            style: textHintTextStyle),
                                        Text(
                                            "${searchMenuList[index].menuName}",
                                            style: textLabelTextStyle),
                                      ],
                                    ),
                                    SizedBox(
                                      height: 3,
                                    ),
                                    Row(
                                      children: [
                                        Text("Category:          ",
                                            style: headHintTextStyle),
                                        Text(
                                            "${searchMenuList[index].menucategory.toString()}",
                                            style: headsubTextStyle),
                                      ],
                                    ),
                                    SizedBox(
                                      height: 3,
                                    ),
                                    Row(
                                      children: [
                                        Text("Amount:            ",
                                            style: headHintTextStyle),
                                        Text(
                                            "Rs.${searchMenuList[index].menuRate.toString()}",
                                            style: headsubTextStyle),
                                      ],
                                    ),
                                    SizedBox(
                                      height: 3,
                                    ),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: [
                                        // IconButton(
                                        //   onPressed: () {
                                        //     Navigator.push(
                                        //         context,
                                        //         MaterialPageRoute(
                                        //             builder: (context) =>
                                        //                 PreviewMenu(index,
                                        //                     searchMenuList)));
                                        //   },
                                        //   icon: Icon(
                                        //     Icons.preview,
                                        //     color: Colors.blue,
                                        //   ),
                                        // ),
                                        // IconButton(
                                        //   onPressed: () {
                                        //     Navigator.push(
                                        //         context,
                                        //         MaterialPageRoute(
                                        //             builder: (context) =>
                                        //                 EditMenuScreenNew(index,
                                        //                     searchMenuList)));
                                        //   },
                                        //   icon: Icon(
                                        //     Icons.edit,
                                        //     color: Colors.green,
                                        //   ),
                                        // ),
                                        IconButton(
                                          onPressed: () {
                                            _showMyDialog(
                                                searchMenuList[index].id);
                                          },
                                          icon: Icon(
                                            Icons.delete,
                                            color: Colors.red,
                                          ),
                                        ),
                                      ],
                                    ),
                                    Divider(),
                                  ],
                                )
                              ],
                            ),
                          );
                        }),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

//---------------Mobile Mode End-------------//

  // void ShowMenudetails() {
  //   final Future<Database> dbFuture = databaseHelper.initializeDatabase();
  //   dbFuture.then((value) {
  //     Future<List<Menu>> menuListFuture =
  //         databaseHelper.getmenuList();
  //     menuListFuture.then((MenuCatList) {
  //       setState(() {
  //         this.menuList = MenuCatList;
  //         this.count = MenuCatList.length;
  //         print("Printing Purchalist//${count}");
  //       });
  //     });
  //   });
  // }

  DataRow getRow(int index) {
    int serNo = index+1;
    return DataRow(cells: [
      DataCell(Text(serNo.toString())),
      DataCell(Text(searchMenuList[index].menuName)),
      DataCell(Text(searchMenuList[index].menucategory)),
      DataCell(Text(searchMenuList[index].menuRate.toString())),
      DataCell(
        Row(
          children: [
            // IconButton(
            //   icon: Icon(
            //     Icons.preview,
            //   ),
            //   color: Colors.blue,
            //   onPressed: () {
            //     Navigator.push(
            //         context,
            //         MaterialPageRoute(
            //             builder: (context) =>
            //                 PreviewMenu(index, searchMenuList)));
            //   },
            // ),
            // IconButton(
            //   icon: Icon(
            //     Icons.edit,
            //   ),
            //   color: Colors.green,
            //   onPressed: () {
            //     Navigator.push(
            //         context,
            //         MaterialPageRoute(
            //             builder: (context) =>
            //                 EditMenuScreenNew(index, searchMenuList)));
            //   },
            // ),
            IconButton(
              icon: Icon(
                Icons.delete,
              ),
              color: Colors.red,
              onPressed: () {
                _showMyDialog(searchMenuList[index].id);
              },
            ),
          ],
        ),
      ),
    ]);
  }

  List<DataRow> getDataRowList() {
    List<DataRow> myTempDataRow = List();
    for (int i = 0; i < searchMenuList.length; i++) {
      myTempDataRow.add(getRow(i));
    }
    return myTempDataRow;
  }

  Future<void> _showMyDialog(String id) async {
    return showDialog<void>(
      context: context,
      barrierDismissible: false, // user must tap button!
      builder: (BuildContext context) {
        return SingleChildScrollView(
          child: AlertDialog(
            title: Text(
              "Want To Delete!",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: Colors.deepPurpleAccent,
              ),
            ),
            content: SingleChildScrollView(
              child: ListBody(
                children: <Widget>[],
              ),
            ),
            actions: <Widget>[
              TextButton(
                child: Text('Cancel'),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
              TextButton(
                child: Text('Delete'),
                onPressed: () async {
                  MenuList purchasedelete = new MenuList();
                  var result =
                      await purchasedelete.getMenuDelete(id.toString());
                  print("///delete id///$id");
                  Navigator.of(context).pop();
                  _getMenu();
                },
              ),
            ],
          ),
        );
      },
    );
  }

  //-------------------------------------
//from server
  void _getMenu() async {
    setState(() {
      _showCircle = true;
    });
    MenuList purchasefetch = new MenuList();
    var purchaseData = await purchasefetch.getMenu("0");
    print('$purchaseData');
    var resid = purchaseData["resid"];
    if (resid == 200) {
      var rowcount = purchaseData["rowcount"];

      if (rowcount > 0) {
        var purchasesd = purchaseData["menu"];
        List<Menu> tempMenu = [];
        print(purchasesd.length);
        for (var n in purchasesd) {
          Menu pro = Menu.onlymenu(
              n["MenuId"],
              n["MenuName"],
              n["Menucategory"],
              n["Menucategioresname"],
              n["MenuRate"],
              n["MenuGST"]);
          tempMenu.add(pro);
        }

        setState(() {
          menuList = tempMenu;
          searchMenuList = menuList;
          _showCircle = false;
        });
        print("//////purchaselist/////////$menuList.length");

        searchController.addListener(() {
          setState(() {
            if (menuList != null) {
              String s = searchController.text;
              searchMenuList = menuList
                  .where((element) =>
                      element.id
                          .toString()
                          .toLowerCase()
                          .contains(s.toLowerCase()) ||
                      element.menuName
                          .toLowerCase()
                          .contains(s.toLowerCase()) ||
                      element.menucategory
                          .toLowerCase()
                          .contains(s.toLowerCase()) ||
                      element.menuRate
                          .toString()
                          .toLowerCase()
                          .contains(s.toLowerCase()))
                  .toList();
            }
          });
        });
      } else {
        setState(() {
          _showCircle = false;
        });
        String msg = purchaseData["message"];
        Fluttertoast.showToast(
          msg: msg,
          toastLength: Toast.LENGTH_SHORT,
          backgroundColor: PrimaryColor,
          textColor: Color(0xffffffff),
          gravity: ToastGravity.BOTTOM,
        );
      }
    } else {
      String msg = purchaseData["message"];
      Fluttertoast.showToast(
        msg: msg,
        toastLength: Toast.LENGTH_SHORT,
        backgroundColor: PrimaryColor,
        textColor: Color(0xffffffff),
        gravity: ToastGravity.BOTTOM,
      );
    }
  }
}
