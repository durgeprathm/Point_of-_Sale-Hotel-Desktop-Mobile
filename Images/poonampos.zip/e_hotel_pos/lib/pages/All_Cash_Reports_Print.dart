import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:retailerp/EhotelModel/EhotelSales.dart';
import 'package:retailerp/models/Sales.dart';

class AllCashReportPrint extends StatefulWidget {
  final int indexFetch;
  List<EhotelSales> CashList = new List();

  AllCashReportPrint(this.indexFetch, this.CashList);

  @override
  _AllCashReportPrintState createState() =>
      _AllCashReportPrintState(this.indexFetch, this.CashList);
}

class _AllCashReportPrintState extends State<AllCashReportPrint> {
  final int indexFetch;
  List<EhotelSales> CashList = new List();

  _AllCashReportPrintState(this.indexFetch, this.CashList);

  final pdf = pw.Document();
  var imageProvider;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("All Cash Report"),
      ),
      body: PdfPreview(
        build: (format) => _generatePdf(format),
      ),
    );
  }

  Future<Uint8List> _generatePdf(PdfPageFormat format) async {
    pdf.addPage(
      pw.MultiPage(
        build: (context) => [
          pw.Column(
              mainAxisAlignment: pw.MainAxisAlignment.start,
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Text('Retail ERP'),
                pw.SizedBox(height: 5),
                pw.Table.fromTextArray(context: context, data: <List<String>>[
                  <String>[
                    'SN',
                    'Customer Name',
                    'Date',
                    'Discount',
                    'Total\nAmount',
                    'Mode'
                  ],
                  ...CashList.map((data) => [
                    data.menusalesid.toString(),
                    data.customername,
                    data.medate,
                    data.discount,
                    data.totalamount,
                    data.paymodename
                  ])
                ]),
              ])

        ],
      ),
    );

    return pdf.save();
  }

  // DataRow getRow(int index) {
  //   return DataRow(cells: [
  //     DataCell(Text(CashList[index].SalesIDs.toString())),
  //     DataCell(Text(CashList[index].SalesCustomername)),
  //     DataCell(Text(CashList[index].SalesDate)),
  //     DataCell(Text(CashList[index].SalesTotal.toString())),
  //     DataCell(Text(CashList[index].SalesPaymentMode.toString()))
  //   ]);
  // }
  //
  // List<DataRow> getDataRowList() {
  //   List<DataRow> myTempDataRow = List();
  //   for (int i = 0; i < CashList.length; i++) {
  //     myTempDataRow.add(getRow(i));
  //   }
  //   return myTempDataRow;
  // }
}
