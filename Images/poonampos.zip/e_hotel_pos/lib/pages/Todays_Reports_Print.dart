import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:retailerp/EhotelModel/EhotelSales.dart';
import 'package:retailerp/models/Sales.dart';

class TodaysReportPrint extends StatefulWidget {
  final int indexFetch;
  List<EhotelSales> TodaysList = new List();

  TodaysReportPrint(this.indexFetch, this.TodaysList);

  @override
  _TodaysReportPrintState createState() =>
      _TodaysReportPrintState(this.indexFetch, this.TodaysList);
}

class _TodaysReportPrintState extends State<TodaysReportPrint> {
  final int indexFetch;
  List<EhotelSales> TodaysList = new List();

  _TodaysReportPrintState(this.indexFetch, this.TodaysList);

  final pdf = pw.Document();
  var imageProvider;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Today\'s Debit Report"),
      ),
      body: PdfPreview(
        build: (format) => _generatePdf(format),
      ),
    );
  }

  Future<Uint8List> _generatePdf(PdfPageFormat format) async {
    pdf.addPage(
      pw.MultiPage(
        build: (context) => [
          pw.Column(
              mainAxisAlignment: pw.MainAxisAlignment.start,
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Text('Retail ERP'),
                pw.SizedBox(height: 5),
                pw.Table.fromTextArray(context: context, data: <List<String>>[
                  <String>[
                    'SN',
                    'Customer Name',
                    'Date',
                    'Discount',
                    'Total\nAmount',
                    'Mode'
                  ],
                  ...TodaysList.map((data) => [
                    data.menusalesid.toString(),
                    data.customername,
                    data.medate,
                    data.discount,
                    double.parse(data.totalamount).toStringAsFixed(2),
                    data.paymodename
                  ])
                ]),
              ])

        ],
      ),
    );

    return pdf.save();
  }

  // DataRow getRow(int index) {
  //   return DataRow(cells: [
  //     DataCell(Text(TodaysList[index].menusalesid.toString())),
  //     DataCell(Text(TodaysList[index].customername)),
  //     DataCell(Text(TodaysList[index].medate)),
  //     DataCell(Text(TodaysList[index].totalamount.toString())),
  //     DataCell(Text(TodaysList[index].paymodename.toString()))
  //   ]);
  // }
  //
  // List<DataRow> getDataRowList() {
  //   List<DataRow> myTempDataRow = List();
  //   for (int i = 0; i < TodaysList.length; i++) {
  //     myTempDataRow.add(getRow(i));
  //   }
  //   return myTempDataRow;
  // }
}
