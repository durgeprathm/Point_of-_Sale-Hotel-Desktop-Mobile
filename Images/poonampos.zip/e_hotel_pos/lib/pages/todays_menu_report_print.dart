import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:retailerp/EhotelModel/EhotelSales.dart';
import 'package:retailerp/EhotelModel/Ehotelmenu.dart';
import 'package:retailerp/models/Sales.dart';

class TodaysMenuReportPrint extends StatefulWidget {
  final int indexFetch;
  List<Ehotelmenu> TodaysmenuList = new List();

  TodaysMenuReportPrint(this.indexFetch, this.TodaysmenuList);

  @override
  _TodaysMenuReportPrintState createState() =>
      _TodaysMenuReportPrintState(this.indexFetch, this.TodaysmenuList);
}

class _TodaysMenuReportPrintState extends State<TodaysMenuReportPrint> {
  final int indexFetch;
  List<Ehotelmenu> TodaysmenuList = new List();

  _TodaysMenuReportPrintState(this.indexFetch, this.TodaysmenuList);

  final pdf = pw.Document();
  var imageProvider;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Today\'s Menu Report"),
      ),
      body: PdfPreview(
        build: (format) => _generatePdf(format),
      ),
    );
  }

  Future<Uint8List> _generatePdf(PdfPageFormat format) async {
    pdf.addPage(
      pw.MultiPage(
        build: (context) => [
          pw.Column(
              mainAxisAlignment: pw.MainAxisAlignment.start,
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Text('Retail ERP'),
                pw.SizedBox(height: 5),
                pw.Table.fromTextArray(context: context, data: <List<String>>[
                  <String>[
                    'SN',
                    'menu Name',
                    'menu category',
                    'Date',
                    'Quntity',
                    'Rate',
                    'Total\nAmount',
                  ],
                  ...TodaysmenuList.map((data) => [
                    data.menu_id.toString(),
                    data.Menu_Name,
                    data.Menu_Cat_Name,
                    data.Menu_date,
                    data.Menu_Qty_Sum,
                    data.Menu_Rate,
                    double.parse(data.Menu_total_amount).toStringAsFixed(2),
                  ])
                ]),
              ])

        ],
      ),
    );

    return pdf.save();
  }

// DataRow getRow(int index) {
//   return DataRow(cells: [
//     DataCell(Text(TodaysList[index].menusalesid.toString())),
//     DataCell(Text(TodaysList[index].customername)),
//     DataCell(Text(TodaysList[index].medate)),
//     DataCell(Text(TodaysList[index].totalamount.toString())),
//     DataCell(Text(TodaysList[index].paymodename.toString()))
//   ]);
// }
//
// List<DataRow> getDataRowList() {
//   List<DataRow> myTempDataRow = List();
//   for (int i = 0; i < TodaysList.length; i++) {
//     myTempDataRow.add(getRow(i));
//   }
//   return myTempDataRow;
// }
}
