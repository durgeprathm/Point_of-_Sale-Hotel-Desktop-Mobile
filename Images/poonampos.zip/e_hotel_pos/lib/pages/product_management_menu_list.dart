import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:retailerp/pages/add_barcode_screen.dart';
import 'package:retailerp/pages/add_product_screen.dart';
import 'package:retailerp/pages/import_product_screen.dart';
import 'package:retailerp/pages/product_category_menu_list.dart';
import 'package:retailerp/pages/product_menu_list.dart';
import 'package:retailerp/pages/product_rate_menu_list.dart';
import '../widgets/cutom_submenu_list_item.dart';

class ProductManagementMenuList extends StatefulWidget {
  @override
  _ProductManagementMenuListState createState() =>
      _ProductManagementMenuListState();
}

class _ProductManagementMenuListState extends State<ProductManagementMenuList> {
  Widget appBarTitle = Text("Product Management");

  void _selectdItem(int id) {
    switch (id) {
      case 1:
        Navigator.of(context).push(MaterialPageRoute(builder: (_) {
          return ProductCategoryMenuList();
        }));
        break;
      case 2:
        Navigator.of(context).push(MaterialPageRoute(builder: (_) {
          return ProductMenuList();
        }));
        break;
      case 3:
        Navigator.of(context).push(MaterialPageRoute(builder: (_) {
          return ProductRateMenuList();
        }));
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    var screenOrien = MediaQuery.of(context).orientation;
    return Scaffold(
      appBar: AppBar(
        title: appBarTitle,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            screenOrien == Orientation.portrait
                ? getMobileTabs()
                : getTabletsTabs()
          ],
        ),
      ),
    );
  }

  Column getMobileTabs() {
    return Column(
      children: [
        CutomSubMenuListItem.copywith2(
            1,
            'Product Category',
            Color(0xffE57373),
            FaIcon(FontAwesomeIcons.productHunt,
                size: 35.0, color: Colors.white),
            2,
            'Product',
            Color(0xffBA68C8),
            FaIcon(FontAwesomeIcons.shoppingCart,
                size: 35.0, color: Colors.white),
            _selectdItem),
        CutomSubMenuListItem(
            3,
            'Product Rate',
            Color(0xff7986CB),
            FaIcon(FontAwesomeIcons.sortAmountUp,
                size: 35.0, color: Colors.white),
            _selectdItem),
      ],
    );
  }

  Column getTabletsTabs() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        CutomSubMenuListItem.copywith3(
            1,
            'Product Category',
            Color(0xffE57373),
            FaIcon(FontAwesomeIcons.productHunt,
                size: 35.0, color: Colors.white),
            2,
            'Product',
            Color(0xffBA68C8),
            FaIcon(FontAwesomeIcons.shoppingCart,
                size: 35.0, color: Colors.white),
            3,
            'Product Rate',
            Color(0xff7986CB),
            FaIcon(FontAwesomeIcons.sortAmountUp,
                size: 35.0, color: Colors.white),
            _selectdItem),
      ],
    );
  }
}
