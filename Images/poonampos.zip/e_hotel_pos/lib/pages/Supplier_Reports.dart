import 'package:datetime_picker_formfield/datetime_picker_formfield.dart';
import 'package:dropdown_search/dropdown_search.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:intl/intl.dart';
import 'package:retailerp/Adpater/pos_supplier_fetch.dart';
import 'package:retailerp/models/Sales.dart';
import 'package:retailerp/models/supplier.dart';
import 'package:retailerp/utils/const.dart';
import 'package:retailerp/utils/modal_progress_hud.dart';


import 'All_cash_Reports.dart';
import 'Supplier_Reports_Print.dart';

class SupplierReports extends StatefulWidget {
  @override
  _SupplierReportsState createState() => _SupplierReportsState();
}

class _SupplierReportsState extends State<SupplierReports> {
  @override
  //-------------------------------------------
  static const int kTabletBreakpoint = 552;

  @override
  Widget build(BuildContext context) {
    Widget content;
    var shortestSide = MediaQuery.of(context).size.shortestSide;
    print(shortestSide);
    if (shortestSide < kTabletBreakpoint) {
      content = _buildMobileSupplierReports();
    } else {
      content = _buildTableSupplierReports();
    }

    return content;
  }

//=--------mobile--------------
  bool _showCircle = false;
  final _fromDatetext = TextEditingController();
  final _toDatetext = TextEditingController();
  DateTime fromValue = DateTime.now();
  DateTime toValue = DateTime.now();
  final dateFormat = DateFormat("yyyy-MM-dd");
  bool _fromDatevalidate = false;
  bool _toDatevalidate = false;
  Widget appBarTitle = Text("Supplier Reports");
  Icon actionIcon = Icon(
    Icons.search,
    color: Colors.white,
  );
//-------------------------------------------
//-------------------------------------------

  //DatabaseHelper databaseHelper = DatabaseHelper();
  String PaymentMode;
  final initialValue = DateTime.now();
  int changedCount = 0;
  int savedCount = 0;
  bool autoValidate = false;
  bool showResetIcon = false;
  bool readOnly = false;
  bool Datetofromenable = false;
  List<Supplier> SupplierList = new List();
  List<Supplier> SupplierListSearch = new List();
  TextEditingController SerachController = new TextEditingController();
  int count;

  @override
  void initState() {
    _getSales();
  }

  //---------------Tablet Mode Start-------------//
  Widget _buildTableSupplierReports() {
    var tabletWidth = MediaQuery.of(context).size.width * 0.20;
    var tabletWidthSearch = MediaQuery.of(context).size.width * 0.30;
    void handleClick(String value) {
      switch (value) {
        case 'Supplier Product Wise Reports':
          Navigator.push(context,
              MaterialPageRoute(builder: (context) => AllCashReports()));
          break;
      }
    }

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Row(
          children: [
            FaIcon(FontAwesomeIcons.book),
            SizedBox(
              width: 20.0,
            ),
            Text('Supplier Reports'),
          ],
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.home, color: Colors.white),
            onPressed: () {
              Navigator.popUntil(
                  context, ModalRoute.withName(Navigator.defaultRouteName));
            },
          ),
          SupplierList.length != 0
              ? IconButton(
                  icon: Icon(Icons.print, color: Colors.white),
                  onPressed: () {
                    Navigator.of(context).push(MaterialPageRoute(builder: (_) {
                      return SupplierReportPrint(1, SupplierList);
                    }));
                  },
                )
              : Text(''),
          PopupMenuButton<String>(
            onSelected: handleClick,
            itemBuilder: (BuildContext context) {
              return {'Supplier Product Wise Reports'}
                  .map((String choice) {
                return PopupMenuItem<String>(
                  value: choice,
                  child: Text(choice),
                );
              }).toList();
            },
          ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Center(
            child: SupplierList.length == 0
                ? Center(child: CircularProgressIndicator())
                : Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            width: tabletWidthSearch,
                            child: Padding(
                              padding: const EdgeInsets.symmetric(
                                  vertical: 10.0, horizontal: 20.0),
                              child: TextField(
                                controller: SerachController,
                                style: TextStyle(
                                  color: Colors.blueGrey,
                                ),
                                decoration: InputDecoration(
                                    hintText: "Start typing here..",
                                    suffixIcon: IconButton(
                                      icon: Icon(Icons.search),
                                      color: PrimaryColor,
                                      onPressed: () {},
                                    )),
                              ),
                            ),
                          ),
                        ],
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: DataTable(columns: [
                          DataColumn(
                              label: Expanded(
                            child: Container(
                              width: 50,
                              child: Text('Sr No',
                                  style: TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold)),
                            ),
                          )),
                          DataColumn(
                              label: Expanded(
                            child: Container(
                              child: Text('Company',
                                  style: TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold)),
                            ),
                          )),
                          DataColumn(
                              label: Expanded(
                            child: Container(
                              child: Text('Name',
                                  style: TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold)),
                            ),
                          )),
                          DataColumn(
                              label: Expanded(
                            child: Container(
                              child: Text('Mobile',
                                  style: TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold)),
                            ),
                          )),
                          DataColumn(
                              label: Expanded(
                            child: Container(
                              child: Text('Email',
                                  style: TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold)),
                            ),
                          )),
                          DataColumn(
                              label: Expanded(
                            child: Container(
                              child: Text('Address',
                                  style: TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold)),
                            ),
                          )),
                        ], rows: getDataRowList()),
                      ),
                    ],
                  ),
          ),
        ),
      ),
    );
  }

//---------------Tablet Mode End-------------//
//---------------Mobile Mode Start-------------//
  Widget _buildMobileSupplierReports() {
    void handleClick(String value) {
      switch (value) {
        case 'Supplier Product Wise Reports':
          Navigator.push(context,
              MaterialPageRoute(builder: (context) => AllCashReports()));
          break;
      }
    }

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: appBarTitle,
        actions: [
          Row(
            children: [
              IconButton(
                icon: actionIcon,
                onPressed: () {
                  setState(() {
                    if (actionIcon.icon == Icons.search) {
                      actionIcon = new Icon(
                        Icons.close,
                        color: Colors.white,
                      );
                      appBarTitle = TextField(
                        controller: SerachController,
                        style: TextStyle(
                          color: Colors.white,
                        ),
                        decoration: InputDecoration(
                            prefixIcon:
                                new Icon(Icons.search, color: Colors.white),
                            hintText: "Search...",
                            hintStyle: TextStyle(color: Colors.white)),
                      );
                    } else {
                      actionIcon = new Icon(
                        Icons.search,
                        color: Colors.white,
                      );
                      appBarTitle = new Text(
                        "All Reports",
                        style: TextStyle(
                          color: Colors.white,
                        ),
                      );
                      SerachController.clear();
                    }
                  });
                },
              ),
              IconButton(
                icon: Icon(Icons.home, color: Colors.white),
                onPressed: () {
                  Navigator.popUntil(
                      context, ModalRoute.withName(Navigator.defaultRouteName));
                },
              ),
              SupplierList.length != 0
                  ? IconButton(
                      icon: Icon(Icons.print, color: Colors.white),
                      onPressed: () {
                        Navigator.of(context)
                            .push(MaterialPageRoute(builder: (_) {
                          return SupplierReportPrint(1, SupplierList);
                        }));
                      },
                    )
                  : Text(''),
              PopupMenuButton<String>(
                onSelected: handleClick,
                itemBuilder: (BuildContext context) {
                  return {'Supplier Product Wise Reports'}
                      .map((String choice) {
                    return PopupMenuItem<String>(
                      value: choice,
                      child: Text(choice),
                    );
                  }).toList();
                },
              ),
            ],
          ),
        ],
      ),
      body: SafeArea(
        child: ModalProgressHUD(
          inAsyncCall: _showCircle,
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              children: [
                SizedBox(
                  height: 10,
                ),
                Expanded(
                  child: Container(
                    child: ListView.builder(
                        shrinkWrap: true,
                        scrollDirection: Axis.vertical,
                        itemCount: SupplierList.length,
                        itemBuilder: (context, index) {
                          return Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 3),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        "Supplier No:- ${SupplierList[index].Supplierid.toString()} ",
                                        style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 16.0,
                                          color: Colors.black,
                                        ),
                                      ),
                                      Text(
                                        "${SupplierList[index].SupplierMobile}",
                                        style: TextStyle(
                                          fontWeight: FontWeight.normal,
                                          fontSize: 14.0,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(
                                  height: 3,
                                ),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        Text("Customer Company: ",
                                            style: headHintTextStyle),
                                        Text(
                                            "${SupplierList[index].SupplierComapanyName}",
                                            style: headsubTextStyle),
                                      ],
                                    ),
                                    SizedBox(
                                      height: 3,
                                    ),
                                    Row(
                                      children: [
                                        Text("Supplier Company Person Name:",
                                            style: headHintTextStyle),
                                        Text(
                                            "${SupplierList[index].SupplierComapanyPersonName.toString()}",
                                            style: headsubTextStyle),
                                      ],
                                    ),
                                    SizedBox(
                                      height: 3,
                                    ),
                                    Row(
                                      children: [
                                        Text("Email:   ",
                                            style: headHintTextStyle),
                                        Text(
                                            "${SupplierList[index].SupplierEmail.toString()}",
                                            style: headsubTextStyle),
                                      ],
                                    ),
                                    SizedBox(
                                      height: 3,
                                    ),
                                    Divider(),
                                  ],
                                )
                              ],
                            ),
                          );
                        }),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

//---------------Mobile Mode End-------------//

  DataRow getRow(int index) {
    return DataRow(cells: [
      DataCell(Text(SupplierList[index].Supplierid.toString())),
      DataCell(Text(SupplierList[index].SupplierComapanyName)),
      DataCell(Text(SupplierList[index].SupplierComapanyPersonName)),
      DataCell(Text(SupplierList[index].SupplierMobile.toString())),
      DataCell(Text(SupplierList[index].SupplierEmail.toString())),
      DataCell(Text(SupplierList[index].SupplierAddress.toString())),
    ]);
  }

  List<DataRow> getDataRowList() {
    List<DataRow> myTempDataRow = List();

    for (int i = 0; i < SupplierList.length; i++) {
      myTempDataRow.add(getRow(i));
    }
    return myTempDataRow;
  }

  //-------------------------------------
//from server
  void _getSales() async {
    SupplierFetch supplierdata = new SupplierFetch();
    var SupplierFetchData = await supplierdata.getSupplierFetch("1");
    var resid = SupplierFetchData["resid"];

    if (resid == 200) {
      var SupplierFetchsd = SupplierFetchData["supplier"];
      print(SupplierFetchsd.length);
      List<Supplier> tempSupplier = [];
      for (var n in SupplierFetchsd) {
        Supplier pro = Supplier(
            int.parse(n["SupplierId"]),
            n["SupplierCustomername"],
            n["SupplierComapanyPersonName"],
            n["SupplierMobileNumber"],
            n["SupplierEmail"],
            n["SupplierAddress"],
            n["SupplierUdyogAadhar"],
            n["SupplierCINNumber"],
            n["SupplierGSTType"],
            n["SupplierGSTNumber"],
            n["SupplierFAXNumber"],
            n["SupplierPANNumber"],
            n["SupplierLicenseType"],
            n["SupplierLicenseName"],
            n["SupplierBankName"],
            n["SupplierBankBranch"],
            n["SupplierAccountType"],
            n["SupplierAccountNumber"],
            n["SupplierIFSCCode"],
            n["SupplierUPINumber"]);
        tempSupplier.add(pro);
      }
      setState(() {
        this.SupplierList = tempSupplier;
        this.SupplierListSearch = tempSupplier;
      });
      print("//////SalesList/////////$SupplierList.length");

      SerachController.addListener(() {
        setState(() {
          if (SupplierListSearch != null) {
            String s = SerachController.text;
            SupplierList = SupplierListSearch.where((element) =>
                element.Supplierid.toString()
                    .toLowerCase()
                    .contains(s.toLowerCase()) ||
                element.SupplierComapanyName.toLowerCase()
                    .contains(s.toLowerCase()) ||
                element.SupplierComapanyPersonName.toLowerCase().contains(s.toLowerCase()) ||
                element.SupplierMobile.toLowerCase().contains(s.toLowerCase()) ||
                element.SupplierEmail.toString()
                    .toLowerCase()
                    .contains(s.toLowerCase()) ||
                element.SupplierAddress.toString()
                    .toLowerCase()
                    .contains(s.toLowerCase())).toList();
          }
        });
      });
    } else {
      String message = SupplierFetchData["message"];
      Fluttertoast.showToast(
        msg: message,
        toastLength: Toast.LENGTH_SHORT,
        backgroundColor: Colors.black38,
        textColor: Color(0xffffffff),
        gravity: ToastGravity.BOTTOM,
      );
    }
  }

//-------------------------------------
//from server Fetching Payment Mode Data
//   void _getSalesPaymentMode(String PaymentMode) async {
//     ManegeSalesPaymentModeFetch managesalespaymentmodefetch =
//         new ManegeSalesPaymentModeFetch();
//     var managesalespaymentmodefetchData = await managesalespaymentmodefetch
//         .getManageSalesPaymentModeFetch(PaymentMode);
//     var resid = managesalespaymentmodefetchData["resid"];
//
//     if (resid == 200) {
//       var managesalespaymentmodefetchDatasd =
//           managesalespaymentmodefetchData["sales"];
//       print(managesalespaymentmodefetchDatasd.length);
//       List<Sales> tempmanagesalespaymentmodefetchDatasd = [];
//       for (var n in managesalespaymentmodefetchDatasd) {
//         Sales pro = Sales.ManageList(
//             int.parse(n["SalesId"]),
//             n["SalesCustomername"],
//             n["SalesDate"],
//             n["SalesProductName"],
//             n["SalesProductRate"],
//             n["SalesProductQty"],
//             n["SalesProductSubTotal"],
//             n["SalesSubTotal"],
//             n["SalesDiscount"],
//             n["SalesGST"],
//             n["SalesTotalAmount"],
//             n["SalesNarration"],
//             n["SalesPaymentMode"],
//             n["SalesProductIDs"]);
//         tempmanagesalespaymentmodefetchDatasd.add(pro);
//       }
//       setState(() {
//         this.SalesList = tempmanagesalespaymentmodefetchDatasd;
//       });
//       print("//////SalesList/////////$SalesList.length");
//     } else {
//       String message = managesalespaymentmodefetchData["message"];
//       Fluttertoast.showToast(
//         msg: message,
//         toastLength: Toast.LENGTH_SHORT,
//         backgroundColor: Colors.black38,
//         textColor: Color(0xffffffff),
//         gravity: ToastGravity.BOTTOM,
//       );
//     }
//   }
//-------------------------------------

//from server Fetching with paymentmode  And Date
//   void _getbothpaymentDate(
//       String paymentmode, String Datefrom, String dateto) async {
//     ManegeSalesPaymentModeDateWiseFetch managesalespaymentmodedatewisefetch =
//         new ManegeSalesPaymentModeDateWiseFetch();
//     var managesalespaymentmodedatewisefetchData =
//         await managesalespaymentmodedatewisefetch
//             .getManageSalesPaymentModeDateWiseFetch(
//                 paymentmode, Datefrom, dateto);
//     var resid = managesalespaymentmodedatewisefetchData["resid"];
//
//     if (resid == 200) {
//       var managesalespaymentmodedatewisefetchsd =
//           managesalespaymentmodedatewisefetchData["sales"];
//       print(managesalespaymentmodedatewisefetchsd.length);
//       List<Sales> tempmanagesalespaymentmodedatewisefetch = [];
//       for (var n in managesalespaymentmodedatewisefetchsd) {
//         Sales pro = Sales.ManageList(
//             int.parse(n["SalesId"]),
//             n["SalesCustomername"],
//             n["SalesDate"],
//             n["SalesProductName"],
//             n["SalesProductRate"],
//             n["SalesProductQty"],
//             n["SalesProductSubTotal"],
//             n["SalesSubTotal"],
//             n["SalesDiscount"],
//             n["SalesGST"],
//             n["SalesTotalAmount"],
//             n["SalesNarration"],
//             n["SalesPaymentMode"],
//             n["SalesProductIDs"]);
//         tempmanagesalespaymentmodedatewisefetch.add(pro);
//       }
//       setState(() {
//         this.SalesList = tempmanagesalespaymentmodedatewisefetch;
//       });
//       print("//////SalesList/////////$SalesList.length");
//     } else {
//       String message = managesalespaymentmodedatewisefetchData["message"];
//       Fluttertoast.showToast(
//         msg: message,
//         toastLength: Toast.LENGTH_SHORT,
//         backgroundColor: Colors.black38,
//         textColor: Color(0xffffffff),
//         gravity: ToastGravity.BOTTOM,
//       );
//     }
//   }

  //from server Fetching with Date
  // void _getDatewise(String Datefrom, String dateto) async {
  //   SalesDateWiseFetch salesdatewisefetch = new SalesDateWiseFetch();
  //   var salesdatewisefetchData =
  //       await salesdatewisefetch.getSalesDateWiseFetchFetch(Datefrom, dateto);
  //   var resid = salesdatewisefetchData["resid"];
  //
  //   if (resid == 200) {
  //     var salesdatewisefetchfetchsd = salesdatewisefetchData["sales"];
  //     print(salesdatewisefetchfetchsd.length);
  //     List<Sales> tempsalesdatewisefetchfetch = [];
  //     for (var n in salesdatewisefetchfetchsd) {
  //       Sales pro = Sales.ManageList(
  //           int.parse(n["SalesId"]),
  //           n["SalesCustomername"],
  //           n["SalesDate"],
  //           n["SalesProductName"],
  //           n["SalesProductRate"],
  //           n["SalesProductQty"],
  //           n["SalesProductSubTotal"],
  //           n["SalesSubTotal"],
  //           n["SalesDiscount"],
  //           n["SalesGST"],
  //           n["SalesTotalAmount"],
  //           n["SalesNarration"],
  //           n["SalesPaymentMode"],
  //           n["SalesProductIDs"]);
  //       tempsalesdatewisefetchfetch.add(pro);
  //     }
  //     setState(() {
  //       this.SalesList = tempsalesdatewisefetchfetch;
  //     });
  //     print("//////SalesList/////////$SalesList.length");
  //   } else {
  //     String message = salesdatewisefetchData["message"];
  //     Fluttertoast.showToast(
  //       msg: message,
  //       toastLength: Toast.LENGTH_SHORT,
  //       backgroundColor: Colors.black38,
  //       textColor: Color(0xffffffff),
  //       gravity: ToastGravity.BOTTOM,
  //     );
  //   }
  // }
}
