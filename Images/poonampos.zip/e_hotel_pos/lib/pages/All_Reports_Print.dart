import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:retailerp/EhotelModel/EhotelSales.dart';
import 'package:retailerp/models/Sales.dart';

class AllReportPrint extends StatefulWidget {
  final int indexFetch;
  List<EhotelSales> AllList = new List();

  AllReportPrint(this.indexFetch, this.AllList);

  @override
  _AllReportPrintState createState() =>
      _AllReportPrintState(this.indexFetch, this.AllList);
}

class _AllReportPrintState extends State<AllReportPrint> {
  final int indexFetch;
  List<EhotelSales> AllList = new List();

  _AllReportPrintState(this.indexFetch, this.AllList);

  final pdf = pw.Document();
  var imageProvider;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("All Report"),
      ),
      body: PdfPreview(
        build: (format) => _generatePdf(format),
      ),
    );
  }

  Future<Uint8List> _generatePdf(PdfPageFormat format) async {
    pdf.addPage(
      pw.MultiPage(
        build: (context) => [
          pw.Column(
              mainAxisAlignment: pw.MainAxisAlignment.start,
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Text('Retail ERP'),
                pw.SizedBox(height: 5),
                pw.Table.fromTextArray(context: context, data: <List<String>>[
                  <String>[
                    'SN',
                    'Customer Name',
                    'Date',
                    'Discount',
                    'Total\nAmount',
                    'Mode'
                  ],
                  ...AllList.map((data) => [
                    data.menusalesid.toString(),
                    data.customername,
                    data.medate,
                    data.discount,
                    data.totalamount,
                    data.paymodename
                  ])
                ]),
              ])

        ],
      ),
    );

    return pdf.save();
  }

  // DataRow getRow(int index) {
  //   return DataRow(cells: [
  //     DataCell(Text(AllList[index].SalesIDs.toString())),
  //     DataCell(Text(AllList[index].SalesCustomername)),
  //     DataCell(Text(AllList[index].SalesDate)),
  //     DataCell(Text(AllList[index].SalesTotal.toString())),
  //     DataCell(Text(AllList[index].SalesPaymentMode.toString()))
  //   ]);
  // }
  //
  // List<DataRow> getDataRowList() {
  //   List<DataRow> myTempDataRow = List();
  //   for (int i = 0; i < AllList.length; i++) {
  //     myTempDataRow.add(getRow(i));
  //   }
  //   return myTempDataRow;
  // }
}
