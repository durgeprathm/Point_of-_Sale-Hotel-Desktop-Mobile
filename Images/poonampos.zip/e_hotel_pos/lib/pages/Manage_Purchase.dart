import 'package:datetime_picker_formfield/datetime_picker_formfield.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:intl/intl.dart';
import 'package:retailerp/Adpater/pos_purchase_fetch.dart';
import 'package:retailerp/Adpater/pos_purchse_delete.dart';
import 'package:retailerp/helpers/database_helper.dart';
import 'package:retailerp/models/Purchase.dart';
import 'package:retailerp/pages/edit_perchase_screen_new.dart';
import 'package:retailerp/utils/const.dart';
import 'package:retailerp/utils/modal_progress_hud.dart';
import 'package:sqflite/sqflite.dart';

import 'Add_Supliers.dart';
import 'Add_purchase.dart';
import 'Import_purchase.dart';
import 'Manage_Suppliers.dart';
import 'Edit_Perchase_Screen.dart';
import 'Preview_Purchase.dart';
import 'dashboard.dart';

class Managepurchase extends StatefulWidget {
  @override
  _ManagepurchaseState createState() => _ManagepurchaseState();
}

class _ManagepurchaseState extends State<Managepurchase> {
  @override
  // DatabaseHelper databaseHelper = DatabaseHelper();
  List<Purchase> purchaseList = [];
  List<Purchase> searchPurchaseList = [];
  int count;
  final dateFormat = DateFormat("yyyy-MM-dd");
  final initialValue = DateTime.now();
  final _fromDatetext = TextEditingController();
  final _toDatetext = TextEditingController();
  DateTime fromValue = DateTime.now();
  DateTime toValue = DateTime.now();
  bool _fromDatevalidate = false;
  bool _toDatevalidate = false;
  int changedCount = 0;
  int savedCount = 0;
  bool autoValidate = false;
  bool showResetIcon = false;
  bool readOnly = false;
  bool Datetofromenable = false;

  TextEditingController searchController = TextEditingController();

  bool _showCircle = false;
  Icon actionIcon = Icon(
    Icons.search,
    color: Colors.white,
  );
  Widget appBarTitle = Text("Manage Purchase");

  @override
  void initState() {
    final DateTime now = DateTime.now();
    final DateTime pre = new DateTime(now.year, now.month - 1, now.day);
    final String toDate = dateFormat.format(now);
    final String formDate = dateFormat.format(pre);
    _toDatetext.text = toDate;
    _fromDatetext.text = formDate;
    _getPurchase('2', '', _fromDatetext.text, _toDatetext.text);
  }

  //-------------------------------------------
  static const int kTabletBreakpoint = 552;

  @override
  Widget build(BuildContext context) {
    Widget content;
    var shortestSide = MediaQuery.of(context).size.shortestSide;
    print(shortestSide);
    if (shortestSide < kTabletBreakpoint) {
      content = _buildMobileManagepurchase();
    } else {
      content = _buildTabletManagepurchase();
    }

    return content;
  }

//-------------------------------------------
//---------------Tablet Mode Start-------------//
  Widget _buildTabletManagepurchase() {
    void handleClick(String value) {
      switch (value) {
        case 'Add Purchase':
          Navigator.push(
              context, MaterialPageRoute(builder: (context) => AddPurchase()));
          break;
        case 'Import Sales':
          Navigator.push(context,
              MaterialPageRoute(builder: (context) => ImportPurchase()));
          break;
        case 'Add Supplier':
          Navigator.push(context,
              MaterialPageRoute(builder: (context) => AddSupplierDetails()));
          break;
        case 'Manage Suppliers':
          Navigator.push(context,
              MaterialPageRoute(builder: (context) => ManageSuppliers()));
          break;
      }
    }

    var tabletWidth = MediaQuery.of(context).size.width * 0.20;
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Row(
          children: [
            FaIcon(FontAwesomeIcons.shoppingBag),
            SizedBox(
              width: 20.0,
            ),
            Text('Manage Purchase'),
          ],
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.home, color: Colors.white),
            onPressed: () {
              Navigator.popUntil(
                  context, ModalRoute.withName(Navigator.defaultRouteName));
            },
          ),
          PopupMenuButton<String>(
            onSelected: handleClick,
            itemBuilder: (BuildContext context) {
              return {
                'Add Purchase',
                'Import Purchase',
                'Add Supplier',
                'Manage Suppliers',
              }.map((String choice) {
                return PopupMenuItem<String>(
                  value: choice,
                  child: Text(choice),
                );
              }).toList();
            },
          ),
        ],
      ),
      body: SafeArea(
        child: ModalProgressHUD(
          inAsyncCall: _showCircle,
          child: Column(
            children: [
              SizedBox(
                height: 6,
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Container(
                      width: tabletWidth,
                      height: 40,
                      child: TextField(
                        controller: searchController,
                        style: TextStyle(
                          color: Colors.blueGrey,
                        ),
                        decoration: InputDecoration(
                            hintText: "Start typing here..",
                            suffixIcon: IconButton(
                              icon: Icon(Icons.search),
                              color: PrimaryColor,
                              onPressed: () {},
                            )),
                      ),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Container(
                      height: 40,
                      width: tabletWidth,
                      child: DateTimeField(
                        controller: _fromDatetext,
                        format: dateFormat,
                        keyboardType: TextInputType.number,
                        onShowPicker: (context, currentValue) {
                          return showDatePicker(
                              context: context,
                              firstDate: DateTime(1900),
                              initialDate: currentValue ?? DateTime.now(),
                              lastDate: DateTime(2100));
                        },
                        autovalidate: autoValidate,
                        validator: (date) =>
                            date == null ? 'Invalid date' : null,
                        onChanged: (date) => setState(() {
                          fromValue = date;
                          print('Selected Date: ${date}');
                        }),
                        onSaved: (date) => setState(() {
                          fromValue = date;
                          print('Selected value Date: $fromValue');
                          savedCount++;
                        }),
                        resetIcon: showResetIcon ? Icon(Icons.delete) : null,
                        readOnly: readOnly,
                        decoration: InputDecoration(
                          border: OutlineInputBorder(),
                          labelText: 'From Date',
                          errorText:
                              _fromDatevalidate ? 'Enter From Date' : null,
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Container(
                      height: 40,
                      width: tabletWidth,
                      child: DateTimeField(
                        controller: _toDatetext,
                        format: dateFormat,
                        keyboardType: TextInputType.number,
                        onShowPicker: (context, currentValue) {
                          return showDatePicker(
                              context: context,
                              firstDate: DateTime(1900),
                              initialDate: currentValue ?? DateTime.now(),
                              lastDate: DateTime(2100));
                        },
                        autovalidate: autoValidate,
                        autofocus: false,
                        validator: (date) =>
                            date == null ? 'Invalid date' : null,
                        onChanged: (date) => setState(() {
                          toValue = date;
                          print('Selected Date: ${toValue}');
                        }),
                        onSaved: (date) => setState(() {
                          toValue = date;
                          print('Selected value Date: $_toDatetext');
                          savedCount++;
                        }),
                        resetIcon: showResetIcon ? Icon(Icons.delete) : null,
                        readOnly: readOnly,
                        decoration: InputDecoration(
                          border: OutlineInputBorder(),
                          labelText: 'To Date',
                          errorText:
                              _toDatevalidate ? 'Enter Purchase Date' : null,
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Container(
                      height: 40,
                      child: Material(
                        elevation: 5.0,
                        color: PrimaryColor,
                        borderRadius: BorderRadius.circular(10.0),
                        child: MaterialButton(
                          onPressed: () async {
                            setState(() {
                              _fromDatetext.text.isEmpty
                                  ? _fromDatevalidate = true
                                  : _fromDatevalidate = false;
                              _toDatetext.text.isEmpty
                                  ? _toDatevalidate = true
                                  : _toDatevalidate = false;

                              int dateDiff =
                                  toValue.difference(fromValue).inDays;
                              print('Date: $dateDiff');
                              if (dateDiff >= 0) {
                                setState(() {
                                  _showCircle = true;
                                });
                                _getPurchase('2', '', _fromDatetext.text,
                                    _toDatetext.text);
                                // _getbothpaymentDate(PaymentMode,_fromDatetext.text, _toDatetext.text);
                              } else {
                                Fluttertoast.showToast(
                                  msg:
                                      "Select from date must be less than to date!!!",
                                  toastLength: Toast.LENGTH_SHORT,
                                  backgroundColor: Colors.black38,
                                  textColor: Color(0xffffffff),
                                  gravity: ToastGravity.BOTTOM,
                                );
                              }
                            });
                            CircularProgressIndicator();
                            // _toDatetext.clear();
                          },
                          minWidth: 75,
                          child: Padding(
                            padding: const EdgeInsets.all(5.0),
                            child: Text(
                              "Go",
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                                fontSize: 18.0,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Divider(),
              Expanded(
                child: SingleChildScrollView(
                  child: Container(
                    child: Center(
                        child: DataTable(columns: [
                      DataColumn(
                          label: Expanded(
                        child: Container(
                          child: Center(
                            child: Text('Sr No', style: tableColmTextStyle),
                          ),
                        ),
                      )),
                      DataColumn(
                          label: Expanded(
                        child: Container(
                          child: Center(
                            child: Text('Date', style: tableColmTextStyle),
                          ),
                        ),
                      )),
                      DataColumn(
                          label: Expanded(
                        child: Container(
                          child: Center(
                            child: Text('Supplier Name',
                                style: tableColmTextStyle),
                          ),
                        ),
                      )),
                      DataColumn(
                          label: Expanded(
                        child: Container(
                          child: Center(
                            child:
                                Text('Invoice No', style: tableColmTextStyle),
                          ),
                        ),
                      )),
                      DataColumn(
                          label: Expanded(
                        child: Container(
                          child: Center(
                            child:
                                Text('Total Amount', style: tableColmTextStyle),
                          ),
                        ),
                      )),
                      DataColumn(
                          label: Expanded(
                        child: Container(
                          child: Center(
                            child: Text('Action', style: tableColmTextStyle),
                          ),
                        ),
                      )),
                    ], rows: getDataRowList())),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

//---------------Tablet Mode End-------------//
//---------------Mobile Mode Start-------------//
  Widget _buildMobileManagepurchase() {
    void handleClick(String value) {
      switch (value) {
        case 'Add Purchase':
          Navigator.push(
              context, MaterialPageRoute(builder: (context) => AddPurchase()));
          break;
        case 'Import Sales':
          Navigator.push(context,
              MaterialPageRoute(builder: (context) => ImportPurchase()));
          break;
        case 'Add Supplier':
          Navigator.push(context,
              MaterialPageRoute(builder: (context) => AddSupplierDetails()));
          break;
        case 'Manage Suppliers':
          Navigator.push(context,
              MaterialPageRoute(builder: (context) => ManageSuppliers()));
          break;
      }
    }

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: appBarTitle,
        actions: [
          Row(
            children: [
              IconButton(
                icon: actionIcon,
                onPressed: () {
                  setState(() {
                    if (actionIcon.icon == Icons.search) {
                      actionIcon = new Icon(
                        Icons.close,
                        color: Colors.white,
                      );
                      appBarTitle = TextField(
                        controller: searchController,
                        style: TextStyle(
                          color: Colors.white,
                        ),
                        decoration: InputDecoration(
                            prefixIcon:
                                new Icon(Icons.search, color: Colors.white),
                            hintText: "Search...",
                            hintStyle: TextStyle(color: Colors.white)),
                      );
                    } else {
                      actionIcon = new Icon(
                        Icons.search,
                        color: Colors.white,
                      );
                      appBarTitle = new Text(
                        "Manage Purchase",
                        style: TextStyle(
                          color: Colors.white,
                        ),
                      );
                      searchController.clear();
                    }
                  });
                },
              ),
              IconButton(
                icon: Icon(Icons.home, color: Colors.white),
                onPressed: () {
                  Navigator.popUntil(
                      context, ModalRoute.withName(Navigator.defaultRouteName));
                },
              ),
            ],
          ),
          PopupMenuButton<String>(
            onSelected: handleClick,
            itemBuilder: (BuildContext context) {
              return {
                'Add Purchase',
                'Import Purchase',
                'Add Supplier',
                'Manage Suppliers',
              }.map((String choice) {
                return PopupMenuItem<String>(
                  value: choice,
                  child: Text(choice),
                );
              }).toList();
            },
          ),
        ],
      ),
      body: SafeArea(
        child: ModalProgressHUD(
          inAsyncCall: _showCircle,
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(
                  children: [
                    Expanded(
                      child: Container(
                        height: 40,
                        child: DateTimeField(
                          controller: _fromDatetext,
                          format: dateFormat,
                          keyboardType: TextInputType.number,
                          onShowPicker: (context, currentValue) {
                            return showDatePicker(
                                context: context,
                                firstDate: DateTime(1900),
                                initialDate: currentValue ?? DateTime.now(),
                                lastDate: DateTime(2100));
                          },
                          autovalidate: autoValidate,
                          validator: (date) =>
                              date == null ? 'Invalid date' : null,
                          onChanged: (date) => setState(() {
                            fromValue = date;
                            print('Selected Date: ${date}');
                          }),
                          onSaved: (date) => setState(() {
                            fromValue = date;
                            print('Selected value Date: $fromValue');
                            savedCount++;
                          }),
                          resetIcon: showResetIcon ? Icon(Icons.delete) : null,
                          readOnly: readOnly,
                          decoration: InputDecoration(
                            border: OutlineInputBorder(),
                            labelText: 'From Date',
                            errorText:
                                _fromDatevalidate ? 'Enter From Date' : null,
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Expanded(
                      child: Container(
                        height: 40,
                        child: DateTimeField(
                          controller: _toDatetext,
                          format: dateFormat,
                          keyboardType: TextInputType.number,
                          onShowPicker: (context, currentValue) {
                            return showDatePicker(
                                context: context,
                                firstDate: DateTime(1900),
                                initialDate: currentValue ?? DateTime.now(),
                                lastDate: DateTime(2100));
                          },
                          autovalidate: autoValidate,
                          validator: (date) =>
                              date == null ? 'Invalid date' : null,
                          onChanged: (date) => setState(() {
                            toValue = date;
                            print('Selected Date: ${toValue}');
                          }),
                          onSaved: (date) => setState(() {
                            toValue = date;
                            print('Selected value Date: $_toDatetext');
                            savedCount++;
                          }),
                          resetIcon: showResetIcon ? Icon(Icons.delete) : null,
                          readOnly: readOnly,
                          decoration: InputDecoration(
                            border: OutlineInputBorder(),
                            labelText: 'To Date',
                            errorText:
                                _toDatevalidate ? 'Enter Purchase Date' : null,
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Container(
                      width: 60,
                      height: 40,
                      child: Material(
                        elevation: 5.0,
                        color: PrimaryColor,
                        borderRadius: BorderRadius.circular(10.0),
                        child: MaterialButton(
                          onPressed: () async {
                            setState(() {
                              _fromDatetext.text.isEmpty
                                  ? _fromDatevalidate = true
                                  : _fromDatevalidate = false;
                              _toDatetext.text.isEmpty
                                  ? _toDatevalidate = true
                                  : _toDatevalidate = false;

                              int dateDiff =
                                  toValue.difference(fromValue).inDays;
                              print('Date: $dateDiff');
                              if (dateDiff >= 0) {
                                _getPurchase('2', '', _fromDatetext.text,
                                    _toDatetext.text);
                              } else {
                                Fluttertoast.showToast(
                                  msg:
                                      "Select from date must be less than to date!!!",
                                  toastLength: Toast.LENGTH_SHORT,
                                  backgroundColor: Colors.black38,
                                  textColor: Color(0xffffffff),
                                  gravity: ToastGravity.BOTTOM,
                                );
                              }
                            });
                          },
                          minWidth: 60,
                          height: 5.0,
                          child: Padding(
                            padding: const EdgeInsets.all(2.0),
                            child: Text(
                              "Go",
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                                fontSize: 15.0,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Divider(),
              Expanded(
                child: Container(
                  child: GestureDetector(
                    child: ListView.builder(
                        shrinkWrap: true,
                        scrollDirection: Axis.vertical,
                        itemCount: searchPurchaseList.length,
                        itemBuilder: (context, index) {
                          return Padding(
                            padding: const EdgeInsets.symmetric(
                                vertical: 3, horizontal: 8),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        "Invoice No:- ${searchPurchaseList[index].Purchaseid.toString()} ",
                                        style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 18.0,
                                          color: Colors.black,
                                        ),
                                      ),
                                      Text(
                                        "${searchPurchaseList[index].PurchaseDate}",
                                        style: TextStyle(
                                          fontWeight: FontWeight.normal,
                                          fontSize: 16.0,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(
                                  height: 3,
                                ),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        Text("Company Name: ",
                                            style: headHintTextStyle),
                                        Text(
                                            "${searchPurchaseList[index].PurchaseCompanyname}",
                                            style: headsubTextStyle),
                                      ],
                                    ),
                                    SizedBox(
                                      height: 3,
                                    ),
                                    Row(
                                      children: [
                                        Text("Total Amount:      ",
                                            style: headHintTextStyle),
                                        Text(
                                            "Rs.${searchPurchaseList[index].PurchaseTotal.toString()}",
                                            style: headsubTextStyle),
                                      ],
                                    ),
                                    SizedBox(
                                      height: 3,
                                    ),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: [
                                        IconButton(
                                          onPressed: () {
                                            Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                    builder: (context) =>
                                                        PreviewPurchase(index,
                                                            searchPurchaseList)));
                                          },
                                          icon: Icon(
                                            Icons.preview,
                                            color: Colors.blue,
                                          ),
                                        ),
                                        IconButton(
                                          onPressed: () {
                                            Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                    builder: (context) =>
                                                        EditPurchaseScreenNew(
                                                            index,
                                                            searchPurchaseList)));
                                          },
                                          icon: Icon(
                                            Icons.edit,
                                            color: Colors.green,
                                          ),
                                        ),
                                        IconButton(
                                          onPressed: () {
                                            _showMyDialog(
                                                searchPurchaseList[index]
                                                    .Purchaseid);
                                          },
                                          icon: Icon(
                                            Icons.delete,
                                            color: Colors.red,
                                          ),
                                        ),
                                      ],
                                    ),
                                    Divider(),
                                  ],
                                )
                              ],
                            ),
                          );
                        }),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

//---------------Mobile Mode End-------------//

  // void ShowPurchasedetails() {
  //   final Future<Database> dbFuture = databaseHelper.initializeDatabase();
  //   dbFuture.then((value) {
  //     Future<List<Purchase>> purchaseListFuture =
  //         databaseHelper.getpurchaseList();
  //     purchaseListFuture.then((PurchaseCatList) {
  //       setState(() {
  //         this.purchaseList = PurchaseCatList;
  //         this.count = PurchaseCatList.length;
  //         print("Printing Purchalist//${count}");
  //       });
  //     });
  //   });
  // }

  DataRow getRow(int index) {
    var serNo = index + 1;

    return DataRow(cells: [
      DataCell(Center(child: Text(serNo.toString()))),
      DataCell(Center(child: Text(searchPurchaseList[index].PurchaseDate))),
      DataCell(
          Center(child: Text(searchPurchaseList[index].PurchaseCompanyname))),
      DataCell(Center(child: Text(searchPurchaseList[index].Purchaseinvoice))),
      DataCell(Center(
          child: Text(searchPurchaseList[index].PurchaseTotal.toString()))),
      DataCell(
        Center(
          child: Row(
            children: [
              IconButton(
                icon: Icon(
                  Icons.preview,
                ),
                color: Colors.blue,
                onPressed: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                              PreviewPurchase(index, searchPurchaseList)));
                },
              ),
              IconButton(
                icon: Icon(
                  Icons.edit,
                ),
                color: Colors.green,
                onPressed: () {
                  // Navigator.push(
                  //     context,
                  //     MaterialPageRoute(
                  //         builder: (context) => EditPurchaseScreenNew(
                  //             index, searchPurchaseList)));

                  Navigator.of(context)
                      .push(MaterialPageRoute(
                          builder: (context) =>
                              EditPurchaseScreenNew(index, searchPurchaseList)))
                      .then((value) => _reload(value));
                },
              ),
              IconButton(
                icon: Icon(
                  Icons.delete,
                ),
                color: Colors.red,
                onPressed: () {
                  _showMyDialog(searchPurchaseList[index].Purchaseid);
                },
              ),
            ],
          ),
        ),
      ),
    ]);
  }

  List<DataRow> getDataRowList() {
    List<DataRow> myTempDataRow = List();
    for (int i = 0; i < searchPurchaseList.length; i++) {
      myTempDataRow.add(getRow(i));
    }
    return myTempDataRow;
  }

  Future<void> _showMyDialog(int id) async {
    return showDialog<void>(
      context: context,
      barrierDismissible: false, // user must tap button!
      builder: (BuildContext context) {
        return SingleChildScrollView(
          child: AlertDialog(
            title: Text(
              "Want To Delete!",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: Colors.deepPurpleAccent,
              ),
            ),
            content: SingleChildScrollView(
              child: ListBody(
                children: <Widget>[],
              ),
            ),
            actions: <Widget>[
              TextButton(
                child: Text('Cancel'),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
              TextButton(
                child: Text('Delete'),
                onPressed: () async {
                  PurchaseDelete purchasedelete = new PurchaseDelete();
                  var result =
                      await purchasedelete.getPurchaseDelete(id.toString());
                  print("//////////////////Print result//////$result");
                  print("///delete id///$id");
                  Navigator.of(context).pop();
                  _getPurchase('0', '', '', '');
                },
              ),
            ],
          ),
        );
      },
    );
  }

  //-------------------------------------
//from server
  void _getPurchase(action, suplierId, fromDate, toDate) async {
    setState(() {
      _showCircle = true;
    });
    PurchaseFetch purchasefetch = new PurchaseFetch();
    var purchaseData = await purchasefetch.getDatewisePurchaseReportFetch(
        action, suplierId, fromDate, toDate);
    print('$purchaseData');
    var resid = purchaseData["resid"];
    if (resid == 200) {
      var rowcount = purchaseData["rowcount"];
      if (rowcount > 0) {
        var purchasesd = purchaseData["purchasereport"];
        List<Purchase> tempPurchase = [];
        print(purchasesd.length);
        // for (var n in purchasesd) {
        //   Purchase pro = Purchase.withSupplier(
        //     n+1,
        //     int.parse(n["Purchaseid"]),
        //     n["SupplierCustomername"],
        //     n["purchaseinvoice"],
        //     n["PurchaseDate"],
        //     n["purchseproductid"],
        //     n["purchseproductname"],
        //     n["purchseproductrate"],
        //     n["purchseproductquntity"],
        //     n["purchseproductsubtotal"],
        //     n["PurchaseSubTotal"],
        //     n["PurchaseDiscount"],
        //     n["purchseproductgst"],
        //     n["PurchaseMiscellaneons"],
        //     n["PurchaseTotal_Amount"],
        //     n["PurchaseNarration"],
        //     n["purchasesupplierid"],
        //     n["SupplierCustomername"],
        //     n["SupplierComapanyPersonName"],
        //     n["SupplierMobileNumber"],
        //     n["SupplierEmail"],
        //     n["SupplierAddress"],
        //     n["SupplierGSTNumber"],
        //   );
        //   tempPurchase.add(pro);
        // }
        for (int i = 0; i < purchasesd.length; i++) {
          Purchase pro = Purchase.withSupplier(
            i + 1,
            int.parse(purchasesd[i]["Purchaseid"]),
            purchasesd[i]["SupplierCustomername"],
            purchasesd[i]["purchaseinvoice"],
            purchasesd[i]["PurchaseDate"],
            purchasesd[i]["purchseproductid"],
            purchasesd[i]["purchseproductname"],
            purchasesd[i]["purchseproductrate"],
            purchasesd[i]["purchseproductquntity"],
            purchasesd[i]["purchseproductsubtotal"],
            purchasesd[i]["PurchaseSubTotal"],
            purchasesd[i]["PurchaseDiscount"],
            purchasesd[i]["purchseproductgst"],
            purchasesd[i]["PurchaseMiscellaneons"],
            purchasesd[i]["PurchaseTotal_Amount"],
            purchasesd[i]["PurchaseNarration"],
            purchasesd[i]["purchasesupplierid"],
            purchasesd[i]["SupplierCustomername"],
            purchasesd[i]["SupplierComapanyPersonName"],
            purchasesd[i]["SupplierMobileNumber"],
            purchasesd[i]["SupplierEmail"],
            purchasesd[i]["SupplierAddress"],
            purchasesd[i]["SupplierGSTNumber"],
          );
          tempPurchase.add(pro);
        }

        setState(() {
          purchaseList = tempPurchase;
          searchPurchaseList = purchaseList;
          _showCircle = false;
        });
        print("//////purchaselist/////////$purchaseList.length");

        searchController.addListener(() {
          setState(() {
            if (purchaseList != null) {
              String s = searchController.text;
              searchPurchaseList = purchaseList
                  .where((element) =>
                      element.PurchaseIds.toString()
                          .toLowerCase()
                          .contains(s.toLowerCase()) ||
                      element.PurchaseCompanyname.toLowerCase()
                          .contains(s.toLowerCase()) ||
                      element.PurchaseProductName.toLowerCase()
                          .contains(s.toLowerCase()) ||
                      element.PurchaseDate.toLowerCase()
                          .contains(s.toLowerCase()) ||
                      element.PurchaseTotal.toString()
                          .toLowerCase()
                          .contains(s.toLowerCase()))
                  .toList();
            }
          });
        });
      } else {
        setState(() {
          _showCircle = false;
        });
        String msg = purchaseData["message"];
        Fluttertoast.showToast(
          msg: msg,
          toastLength: Toast.LENGTH_SHORT,
          backgroundColor: PrimaryColor,
          textColor: Color(0xffffffff),
          gravity: ToastGravity.BOTTOM,
        );
      }
    } else {
      String msg = purchaseData["message"];
      Fluttertoast.showToast(
        msg: msg,
        toastLength: Toast.LENGTH_SHORT,
        backgroundColor: PrimaryColor,
        textColor: Color(0xffffffff),
        gravity: ToastGravity.BOTTOM,
      );
    }
  }

  _reload(value) {
    _getPurchase('0', '', '', '');
  }
//-------------------------------------
}
