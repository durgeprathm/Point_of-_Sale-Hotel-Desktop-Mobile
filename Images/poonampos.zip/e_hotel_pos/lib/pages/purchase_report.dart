import 'package:datetime_picker_formfield/datetime_picker_formfield.dart';
import 'package:dropdown_search/dropdown_search.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:intl/intl.dart';
import 'package:retailerp/Adpater/pos_purchase_fetch.dart';
import 'package:retailerp/Adpater/pos_supplier_fetch.dart';
import 'package:retailerp/models/Purchase.dart';
import 'package:retailerp/models/supplier.dart';
import 'package:retailerp/pages/purchase_report_print.dart';
import 'package:retailerp/utils/const.dart';
import 'package:retailerp/utils/modal_progress_hud.dart';

import 'Add_Supliers.dart';
import 'Add_purchase.dart';
import 'Import_purchase.dart';
import 'Manage_Suppliers.dart';

class PurchaseReport extends StatefulWidget {
  @override
  _PurchaseReportState createState() => _PurchaseReportState();
}

class _PurchaseReportState extends State<PurchaseReport> {
  @override
  // DatabaseHelper databaseHelper = DatabaseHelper();
  List<Purchase> purchaseList = [];
  List<Purchase> showPurchaseList = [];
  List<Purchase> _searchPurchaseList = [];
  final _fromDatetext = TextEditingController();
  final _toDatetext = TextEditingController();
  List<Supplier> supplierList = new List();
  String pCompanyID;
  String pCompanyName;

  String _fromDate;
  String _toDate;
  bool _fromDatevalidate = false;
  bool _toDatevalidate = false;
  DateTime fromValue = DateTime.now();
  DateTime toValue = DateTime.now();
  int fromChangedCount = 0;
  int fromSavedCount = 0;
  int changedCount = 0;
  int savedCount = 0;
  int count;
  final dateFormat = DateFormat("yyyy-MM-dd");
  final initialValue = DateTime.now();
  bool showResetIcon = false;
  bool readOnly = false;
  bool fetchPurList = false;
  bool setVisibility = false;
  bool autoValidate = false;
  bool _showCircle = false;

  final TextEditingController _searchQuery = new TextEditingController();
  Icon actionIcon = Icon(
    Icons.search,
    color: Colors.white,
  );
  Widget appBarTitle = Text("Purchase Report");

  @override
  void initState() {
    // _getPurchase('', '');
    final DateTime now = DateTime.now();
    final DateTime pre = new DateTime(now.year, now.month - 1, now.day);
    final String toDate = dateFormat.format(now);
    final String formDate = dateFormat.format(pre);
    _toDatetext.text = toDate;
    _fromDatetext.text = formDate;
    _getPurchase(
        '2', '', _fromDatetext.text.toString(), _toDatetext.text.toString());
    _getSupplier();
  }

  //-------------------------------------------
  static const int kTabletBreakpoint = 552;

  @override
  Widget build(BuildContext context) {
    Widget content;
    var shortestSide = MediaQuery.of(context).size.shortestSide;
    print(shortestSide);
    if (shortestSide < kTabletBreakpoint) {
      content = _buildMobilePurchaseReport();
    } else {
      content = _buildTabletPurchaseReport();
    }

    return content;
  }

//-------------------------------------------
//---------------Tablet Mode Start-------------//
  Widget _buildTabletPurchaseReport() {
    var tabletWidth = MediaQuery.of(context).size.width * 0.20;
    var tabletheight = MediaQuery.of(context).size.height * 0.20;
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text('Purchase Report'),
        actions: [
          Row(
            children: [
              IconButton(
                icon: Icon(Icons.home, color: Colors.white),
                onPressed: () {
                  Navigator.popUntil(
                      context, ModalRoute.withName(Navigator.defaultRouteName));
                },
              ),
              _searchPurchaseList.length != 0
                  ? IconButton(
                      icon: Icon(Icons.print, color: Colors.white),
                      onPressed: () {
                        Navigator.of(context)
                            .push(MaterialPageRoute(builder: (_) {
                          return PurchaseReportPrint(1, _searchPurchaseList);
                        }));
                      },
                    )
                  : Text(''),
            ],
          ),
        ],
      ),
      body: SafeArea(
        child: ModalProgressHUD(
          inAsyncCall: _showCircle,
          child: SingleChildScrollView(
            child: Container(
              child: Column(
                children: [
                  SizedBox(
                    height: 6,
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Container(
                          width: tabletWidth,
                          height: 40,
                          child: TextField(
                            controller: _searchQuery,
                            style: TextStyle(
                              color: Colors.blueGrey,
                            ),
                            decoration: InputDecoration(
                                hintText: "Start typing here..",
                                suffixIcon: IconButton(
                                  icon: Icon(Icons.search),
                                  color: PrimaryColor,
                                  onPressed: () {},
                                )),
                          ),
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Container(
                          height: 40,
                          width: tabletWidth,
                          child: DropdownSearch<Supplier>(
                            items: supplierList,
                            showSearchBox: true,
                            showClearButton: true,
                            label: "Supplier Company Name",
                            onChanged: (value) {
                              if (value != null) {
                                pCompanyID = value.Supplierid.toString();
                                pCompanyName = value.SupplierComapanyName;
                                if (_fromDatetext.text.isEmpty ||
                                    _toDatetext.text.isEmpty) {
                                  print('date Empty 1');
                                  _getPurchase('1', value.Supplierid.toString(),
                                      _fromDatetext.text, _toDatetext.text);
                                } else {
                                  print('date Empty 3');
                                  _getPurchase('3', value.Supplierid.toString(),
                                      _fromDatetext.text, _toDatetext.text);
                                }
                                print(pCompanyName);
                              } else {
                                pCompanyID = null;
                                pCompanyName = null;
                                if (_fromDatetext.text.isEmpty ||
                                    _toDatetext.text.isEmpty) {
                                  print('date Value Empty 0');
                                  _getPurchase('0', '', '', '');
                                } else {
                                  print('date Value Empty 2');
                                  _getPurchase('2', '', _fromDatetext.text,
                                      _toDatetext.text);
                                }
                              }
                            },
                          ),
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Container(
                          height: 40,
                          width: tabletWidth,
                          child: DateTimeField(
                            controller: _fromDatetext,
                            format: dateFormat,
                            keyboardType: TextInputType.number,
                            onShowPicker: (context, currentValue) {
                              return showDatePicker(
                                  context: context,
                                  firstDate: DateTime(1900),
                                  initialDate: currentValue ?? DateTime.now(),
                                  lastDate: DateTime(2100));
                            },
                            autovalidate: autoValidate,
                            validator: (date) =>
                                date == null ? 'Invalid date' : null,
                            onChanged: (date) => setState(() {
                              fromValue = date;
                              print('Selected Date: ${date}');
                            }),
                            onSaved: (date) => setState(() {
                              fromValue = date;
                              print('Selected value Date: $fromValue');
                              savedCount++;
                            }),
                            resetIcon:
                                showResetIcon ? Icon(Icons.delete) : null,
                            readOnly: readOnly,
                            decoration: InputDecoration(
                              border: OutlineInputBorder(),
                              labelText: 'From Date',
                              errorText:
                                  _fromDatevalidate ? 'Enter From Date' : null,
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Container(
                          height: 40,
                          width: tabletWidth,
                          child: DateTimeField(
                            controller: _toDatetext,
                            format: dateFormat,
                            keyboardType: TextInputType.number,
                            onShowPicker: (context, currentValue) {
                              return showDatePicker(
                                  context: context,
                                  firstDate: DateTime(1900),
                                  initialDate: currentValue ?? DateTime.now(),
                                  lastDate: DateTime(2100));
                            },
                            autovalidate: autoValidate,
                            validator: (date) =>
                                date == null ? 'Invalid date' : null,
                            onChanged: (date) => setState(() {
                              toValue = date;
                              print('Selected Date: ${toValue}');
                            }),
                            onSaved: (date) => setState(() {
                              toValue = date;
                              print('Selected value Date: $_toDatetext');
                              savedCount++;
                            }),
                            resetIcon:
                                showResetIcon ? Icon(Icons.delete) : null,
                            readOnly: readOnly,
                            decoration: InputDecoration(
                              border: OutlineInputBorder(),
                              labelText: 'To Date',
                              errorText: _toDatevalidate
                                  ? 'Enter Purchase Date'
                                  : null,
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Container(
                          height: 40,
                          child: Material(
                            elevation: 5.0,
                            color: PrimaryColor,
                            borderRadius: BorderRadius.circular(10.0),
                            child: MaterialButton(
                              onPressed: () async {
                                setState(() {
                                  _fromDatetext.text.isEmpty
                                      ? _fromDatevalidate = true
                                      : _fromDatevalidate = false;
                                  _toDatetext.text.isEmpty
                                      ? _toDatevalidate = true
                                      : _toDatevalidate = false;

                                  int dateDiff =
                                      toValue.difference(fromValue).inDays;
                                  print('Date: $dateDiff');
                                  if (dateDiff >= 0) {
                                    setState(() {
                                      _showCircle = true;
                                    });

                                    if (pCompanyID == null) {
                                      _getPurchase('2', '', _fromDatetext.text,
                                          _toDatetext.text);
                                    } else {
                                      _getPurchase('3', pCompanyID.toString(),
                                          _fromDatetext.text, _toDatetext.text);
                                    }
                                    // _getbothpaymentDate(PaymentMode,_fromDatetext.text, _toDatetext.text);
                                  } else {
                                    Fluttertoast.showToast(
                                      msg:
                                          "Select from date must be less than to date!!!",
                                      toastLength: Toast.LENGTH_SHORT,
                                      backgroundColor: Colors.black38,
                                      textColor: Color(0xffffffff),
                                      gravity: ToastGravity.BOTTOM,
                                    );
                                  }
                                });
                                CircularProgressIndicator();
                                // _toDatetext.clear();
                              },
                              minWidth: 75,
                              child: Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: Text(
                                  "Go",
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white,
                                    fontSize: 18.0,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Divider(),
                  Center(
                    child: SingleChildScrollView(
                      child: DataTable(columns: [
                        DataColumn(
                            label: Expanded(
                          child: Container(
                            child: Center(
                              child: Text('SN', style: tableColmTextStyle),
                            ),
                          ),
                        )),
                        DataColumn(
                            label: Expanded(
                          child: Container(
                            child: Center(
                              child:
                                  Text('Order Date', style: tableColmTextStyle),
                            ),
                          ),
                        )),
                        DataColumn(
                            label: Expanded(
                          child: Container(
                            child: Center(
                              child: Text('Supplier Name',
                                  style: tableColmTextStyle),
                            ),
                          ),
                        )),
                        DataColumn(
                            label: Expanded(
                          child: Container(
                            child: Center(
                              child: Text('Invoice No.',
                                  style: tableColmTextStyle),
                            ),
                          ),
                        )),
                        DataColumn(
                            label: Expanded(
                          child: Container(
                            child: Center(
                              child: Text('Total Amount',
                                  style: tableColmTextStyle),
                            ),
                          ),
                        )),
                        DataColumn(
                            label: Expanded(
                          child: Container(
                            child: Center(
                              child: Text('Remark', style: tableColmTextStyle),
                            ),
                          ),
                        )),
                      ], rows: getDataRowList()),
                    ),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  DataRow getRow(int index) {
    print('getRow CAll');
    var srNo = index + 1;
    return DataRow(cells: [
      DataCell(Center(child: Text(srNo.toString()))),
      DataCell(Center(child: Text(_searchPurchaseList[index].PurchaseDate))),
      DataCell(
          Center(child: Text(_searchPurchaseList[index].SupplierCustomername))),
      DataCell(Center(child: Text(_searchPurchaseList[index].Purchaseinvoice))),
      DataCell(Center(child: Text(_searchPurchaseList[index].PurchaseTotal))),
      DataCell(Text(_searchPurchaseList[index].PurchaseNarration)),
    ]);
  }

  List<DataRow> getDataRowList() {
    List<DataRow> myTempDataRow = List();
    for (int i = 0; i < _searchPurchaseList.length; i++) {
      myTempDataRow.add(getRow(i));
    }
    return myTempDataRow;
  }

//---------------Tablet Mode End-------------//
  // void ShowPurchasedetails() {
  //   final Future<Database> dbFuture = databaseHelper.initializeDatabase();
  //   dbFuture.then((value) {
  //     Future<List<Purchase>> PurchaseListFuture =
  //         databaseHelper.getPurchaseList();
  //     PurchaseListFuture.then((PurchaseCatList) {
  //       setState(() {
  //         this.purchaseList = PurchaseCatList;
  //         this.count = PurchaseCatList.length;
  //         print("Printing Purchalist//${count}");
  //       });
  //     });
  //   });
  // }

  Widget _buildMobilePurchaseReport() {
    void handleClick(String value) {
      switch (value) {
        case 'Add Purchase':
          Navigator.push(
              context, MaterialPageRoute(builder: (context) => AddPurchase()));
          break;
        case 'Import Sales':
          Navigator.push(context,
              MaterialPageRoute(builder: (context) => ImportPurchase()));
          break;
        case 'Add Supplier':
          Navigator.push(context,
              MaterialPageRoute(builder: (context) => AddSupplierDetails()));
          break;
        case 'Manage Suppliers':
          Navigator.push(context,
              MaterialPageRoute(builder: (context) => ManageSuppliers()));
          break;
      }
    }

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: appBarTitle,
        actions: [
          Row(
            children: [
              IconButton(
                icon: actionIcon,
                onPressed: () {
                  setState(() {
                    if (actionIcon.icon == Icons.search) {
                      actionIcon = new Icon(
                        Icons.close,
                        color: Colors.white,
                      );
                      appBarTitle = TextField(
                        controller: _searchQuery,
                        style: TextStyle(
                          color: Colors.white,
                        ),
                        decoration: InputDecoration(
                            prefixIcon:
                                new Icon(Icons.search, color: Colors.white),
                            hintText: "Search...",
                            hintStyle: TextStyle(color: Colors.white)),
                      );
                    } else {
                      actionIcon = new Icon(
                        Icons.search,
                        color: Colors.white,
                      );
                      appBarTitle = new Text(
                        "Purchase Report List",
                        style: TextStyle(
                          color: Colors.white,
                        ),
                      );
                      _searchQuery.clear();
                    }
                  });
                },
              ),
              IconButton(
                icon: Icon(Icons.home, color: Colors.white),
                onPressed: () {
                  Navigator.popUntil(
                      context, ModalRoute.withName(Navigator.defaultRouteName));
                },
              ),
              _searchPurchaseList.length != 0
                  ? IconButton(
                      icon: Icon(Icons.print, color: Colors.white),
                      onPressed: () {
                        Navigator.of(context)
                            .push(MaterialPageRoute(builder: (_) {
                          return PurchaseReportPrint(1, _searchPurchaseList);
                        }));
                      },
                    )
                  : Text(''),
            ],
          ),
        ],
      ),
      body: SafeArea(
        child: ModalProgressHUD(
          inAsyncCall: _showCircle,
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(
                  children: [
                    Expanded(
                      child: Container(
                        height: 30,
                        child: DateTimeField(
                          controller: _fromDatetext,
                          format: dateFormat,
                          keyboardType: TextInputType.number,
                          onShowPicker: (context, currentValue) {
                            return showDatePicker(
                                context: context,
                                firstDate: DateTime(1900),
                                initialDate: currentValue ?? DateTime.now(),
                                lastDate: DateTime(2100));
                          },
                          autovalidate: autoValidate,
                          validator: (date) =>
                              date == null ? 'Invalid date' : null,
                          onChanged: (date) => setState(() {
                            fromValue = date;
                            print('Selected Date: ${date}');
                          }),
                          onSaved: (date) => setState(() {
                            fromValue = date;
                            print('Selected value Date: $fromValue');
                            savedCount++;
                          }),
                          resetIcon: showResetIcon ? Icon(Icons.delete) : null,
                          readOnly: readOnly,
                          decoration: InputDecoration(
                            border: OutlineInputBorder(),
                            labelText: 'From Date',
                            errorText:
                                _fromDatevalidate ? 'Enter From Date' : null,
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Expanded(
                      child: Container(
                        height: 30,
                        child: DateTimeField(
                          controller: _toDatetext,
                          format: dateFormat,
                          keyboardType: TextInputType.number,
                          onShowPicker: (context, currentValue) {
                            return showDatePicker(
                                context: context,
                                firstDate: DateTime(1900),
                                initialDate: currentValue ?? DateTime.now(),
                                lastDate: DateTime(2100));
                          },
                          autovalidate: autoValidate,
                          validator: (date) =>
                              date == null ? 'Invalid date' : null,
                          onChanged: (date) => setState(() {
                            toValue = date;
                            print('Selected Date: ${toValue}');
                          }),
                          onSaved: (date) => setState(() {
                            toValue = date;
                            print('Selected value Date: $_toDatetext');
                            savedCount++;
                          }),
                          resetIcon: showResetIcon ? Icon(Icons.delete) : null,
                          readOnly: readOnly,
                          decoration: InputDecoration(
                            border: OutlineInputBorder(),
                            labelText: 'To Date',
                            errorText:
                                _toDatevalidate ? 'Enter Purchase Date' : null,
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Container(
                      width: 60,
                      height: 30,
                      child: Material(
                        elevation: 5.0,
                        color: PrimaryColor,
                        borderRadius: BorderRadius.circular(10.0),
                        child: MaterialButton(
                          onPressed: () async {
                            setState(() {
                              _fromDatetext.text.isEmpty
                                  ? _fromDatevalidate = true
                                  : _fromDatevalidate = false;
                              _toDatetext.text.isEmpty
                                  ? _toDatevalidate = true
                                  : _toDatevalidate = false;

                              int dateDiff =
                                  toValue.difference(fromValue).inDays;
                              print('Date: $dateDiff');
                              if (dateDiff >= 0) {
                                if (pCompanyID == null) {
                                  _getPurchase('2', '', _fromDatetext.text,
                                      _toDatetext.text);
                                } else {
                                  _getPurchase('3', pCompanyID.toString(),
                                      _fromDatetext.text, _toDatetext.text);
                                }
                              } else {
                                Fluttertoast.showToast(
                                  msg:
                                      "Select from date must be less than to date!!!",
                                  toastLength: Toast.LENGTH_SHORT,
                                  backgroundColor: Colors.black38,
                                  textColor: Color(0xffffffff),
                                  gravity: ToastGravity.BOTTOM,
                                );
                              }
                            });
                          },
                          minWidth: 60,
                          height: 5.0,
                          child: Padding(
                            padding: const EdgeInsets.all(2.0),
                            child: Text(
                              "Go",
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                                fontSize: 15.0,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Divider(),
              Expanded(
                child: Container(
                  child: ListView.builder(
                      shrinkWrap: true,
                      scrollDirection: Axis.vertical,
                      itemCount: _searchPurchaseList.length,
                      itemBuilder: (context, index) {
                        return Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 3),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      "Invoice No:- ${_searchPurchaseList[index].Purchaseid.toString()} ",
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 16.0,
                                        color: Colors.black,
                                      ),
                                    ),
                                    Text(
                                      "${_searchPurchaseList[index].PurchaseDate}",
                                      style: TextStyle(
                                        fontWeight: FontWeight.normal,
                                        fontSize: 14.0,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(
                                height: 3,
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Text("Company Name: ",
                                          style: headHintTextStyle),
                                      Text(
                                          "${_searchPurchaseList[index].PurchaseCompanyname}",
                                          style: headsubTextStyle),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 3,
                                  ),
                                  Row(
                                    children: [
                                      Text("Total Amount:      ",
                                          style: headHintTextStyle),
                                      Text(
                                          "Rs.${_searchPurchaseList[index].PurchaseTotal.toString()}",
                                          style: headsubTextStyle),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 3,
                                  ),
                                  Divider(),
                                ],
                              )
                            ],
                          ),
                        );
                      }),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  //-------------------------------------
//from server
  void _getPurchase(action, suplierId, String fromDate, String toDate) async {
    setState(() {
      _showCircle = true;
      purchaseList.clear();
    });
    PurchaseFetch purchasefetch = new PurchaseFetch();
    var purchaseData = await purchasefetch.getDatewisePurchaseReportFetch(
        action, suplierId, fromDate, toDate);
    print('$purchaseData');
    int resid = purchaseData["resid"];
    if (resid == 200) {
      int rowcount = purchaseData["rowcount"];
      if (rowcount > 0) {
        var purchasesd = purchaseData["purchasereport"];
        List<Purchase> tempPurchase = [];
        print(purchasesd.length);
        // for (var n in purchasesd) {
        //   Purchase pro = Purchase.withSupplier(
        //     0,
        //     int.parse(n["Purchaseid"]),
        //     n["SupplierCustomername"],
        //     n["purchaseinvoice"],
        //     n["PurchaseDate"],
        //     n["purchseproductid"],
        //     n["purchseproductname"],
        //     n["purchseproductrate"],
        //     n["purchseproductquntity"],
        //     n["purchseproductsubtotal"],
        //     n["PurchaseSubTotal"],
        //     n["PurchaseDiscount"],
        //     n["purchseproductgst"],
        //     n["PurchaseMiscellaneons"],
        //     n["PurchaseTotal_Amount"],
        //     n["PurchaseNarration"],
        //     n["purchasesupplierid"],
        //     n["SupplierCustomername"],
        //     n["SupplierComapanyPersonName"],
        //     n["SupplierMobileNumber"],
        //     n["SupplierEmail"],
        //     n["SupplierAddress"],
        //     n["SupplierGSTNumber"],
        //   );
        //   tempPurchase.add(pro);
        // }

        for (int i = 0; i < purchasesd.length; i++) {
          Purchase pro = Purchase.withSupplier(
            i+1,
            int.parse(purchasesd[i]["Purchaseid"]),
            purchasesd[i]["SupplierCustomername"],
            purchasesd[i]["purchaseinvoice"],
            purchasesd[i]["PurchaseDate"],
            purchasesd[i]["purchseproductid"],
            purchasesd[i]["purchseproductname"],
            purchasesd[i]["purchseproductrate"],
            purchasesd[i]["purchseproductquntity"],
            purchasesd[i]["purchseproductsubtotal"],
            purchasesd[i]["PurchaseSubTotal"],
            purchasesd[i]["PurchaseDiscount"],
            purchasesd[i]["purchseproductgst"],
            purchasesd[i]["PurchaseMiscellaneons"],
            purchasesd[i]["PurchaseTotal_Amount"],
            purchasesd[i]["PurchaseNarration"],
            purchasesd[i]["purchasesupplierid"],
            purchasesd[i]["SupplierCustomername"],
            purchasesd[i]["SupplierComapanyPersonName"],
            purchasesd[i]["SupplierMobileNumber"],
            purchasesd[i]["SupplierEmail"],
            purchasesd[i]["SupplierAddress"],
            purchasesd[i]["SupplierGSTNumber"],
          );
          tempPurchase.add(pro);
        }

        setState(() {
          purchaseList = tempPurchase;
          _showCircle = false;
          _searchPurchaseList = purchaseList;
          // _getFinalStringList(this.purchaseList);
        });

        _searchQuery.addListener(() {
          setState(() {
            if (purchaseList != null) {
              String s = _searchQuery.text;
              _searchPurchaseList = purchaseList
                  .where((element) =>
                      element.PurchaseIds.toString()
                          .toLowerCase()
                          .contains(s.toLowerCase()) ||
                      element.PurchaseCompanyname.toLowerCase()
                          .contains(s.toLowerCase()) ||
                      element.PurchaseProductName.toLowerCase()
                          .contains(s.toLowerCase()) ||
                      element.PurchaseDate.toLowerCase()
                          .contains(s.toLowerCase()) ||
                      element.PurchaseTotal.toString()
                          .toLowerCase()
                          .contains(s.toLowerCase()))
                  .toList();
            }
          });
        });
      } else {
        setState(() {
          _showCircle = false;
        });
        String msg = purchaseData["message"];
        Fluttertoast.showToast(
          msg: msg,
          toastLength: Toast.LENGTH_SHORT,
          backgroundColor: PrimaryColor,
          textColor: Color(0xffffffff),
          gravity: ToastGravity.BOTTOM,
        );
      }
    } else {
      setState(() {
        _showCircle = false;
      });
      String msg = purchaseData["message"];
      Fluttertoast.showToast(
        msg: msg,
        toastLength: Toast.LENGTH_SHORT,
        backgroundColor: PrimaryColor,
        textColor: Color(0xffffffff),
        gravity: ToastGravity.BOTTOM,
      );
    }
  }

  void _getSupplier() async {
    SupplierFetch supplierfetch = new SupplierFetch();
    var supplierData = await supplierfetch.getHotelSupplierFetch("1");
    print(supplierData);
    var resid = supplierData["resid"];
    if (resid == 200) {
      var rowcount = supplierData["rowcount"];
      if (rowcount > 0) {
        var suppliersd = supplierData["supplier"];
        List<Supplier> tempSupplier = [];
        for (var n in suppliersd) {
          Supplier pro = Supplier(
              int.parse(n["SupplierId"]),
              n["SupplierCustomername"],
              n["SupplierComapanyPersonName"],
              n["SupplierMobileNumber"],
              n["SupplierEmail"],
              n["SupplierAddress"],
              n["SupplierUdyogAadhar"],
              n["SupplierCINNumber"],
              n["SupplierGSTType"],
              n["SupplierGSTNumber"],
              n["SupplierFAXNumber"],
              n["SupplierPANNumber"],
              n["SupplierLicenseType"],
              n["SupplierLicenseName"],
              n["SupplierBankName"],
              n["SupplierBankBranch"],
              n["SupplierAccountType"],
              n["SupplierAccountNumber"],
              n["SupplierIFSCCode"],
              n["SupplierUPINumber"]);
          tempSupplier.add(pro);
        }
        setState(() {
          this.supplierList = tempSupplier;
        });
        print("//////SalesList/////////$supplierList.length");
      } else {}
    } else {}
  }

  void _getFinalStringList(List<Purchase> purchalist) {
    List<Purchase> tempPurchase = [];
    List<String> tableStr = [];
    for (int j = 0; j < purchalist.length; j++) {
      var slipttedProNam = purchalist[j].PurchaseProductName.split("#");
      var slipttedProQty = purchalist[j].PurchaseProductQty.split("#");

      List<String> mytempstrList = [];
      String mytemstr;
      for (int i = 0; i < slipttedProNam.length; i++) {
        mytemstr = "${slipttedProNam[i]} - ${slipttedProQty[i]}";
        mytempstrList.add(mytemstr);
      }
      print(mytempstrList);
      String finalStr = mytempstrList.join(",");

      Purchase pro = Purchase.withProducts(
          j + 1,
          purchalist[j].PurchaseCompanyname,
          purchalist[j].PurchaseDate,
          purchalist[j].PurchaseProductName,
          purchalist[j].PurchaseProductRate,
          purchalist[j].PurchaseProductQty,
          purchalist[j].PurchaseProductSubTotal,
          purchalist[j].PurchaseSubTotal,
          purchalist[j].PurchaseDiscount,
          purchalist[j].PurchaseGST,
          purchalist[j].PurchaseMiscellaneons,
          purchalist[j].PurchaseTotal,
          purchalist[j].PurchaseNarration,
          finalStr);
      tempPurchase.add(pro);

      tableStr.add(finalStr);
    }

    setState(() {
      this.showPurchaseList = tempPurchase;
      _searchPurchaseList = showPurchaseList;
      fetchPurList = false;
      setVisibility = true;
    });

    _searchQuery.addListener(() {
      setState(() {
        if (showPurchaseList != null) {
          String s = _searchQuery.text;
          _searchPurchaseList = showPurchaseList
              .where((element) =>
                  element.PurchaseIds.toString()
                      .toLowerCase()
                      .contains(s.toLowerCase()) ||
                  element.PurchaseCompanyname.toLowerCase()
                      .contains(s.toLowerCase()) ||
                  element.PurchaseProductName.toLowerCase()
                      .contains(s.toLowerCase()) ||
                  element.PurchaseDate.toLowerCase()
                      .contains(s.toLowerCase()) ||
                  element.PurchaseTotal.toString()
                      .toLowerCase()
                      .contains(s.toLowerCase()))
              .toList();
        }
      });
    });
  }
//-------------------------------------
}
