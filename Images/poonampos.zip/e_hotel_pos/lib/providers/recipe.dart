import 'dart:collection';

import 'package:flutter/foundation.dart';

class RecipeItems {
  String _id;
  String _title;
  double _quantity;

  RecipeItems(this._id, this._title, this._quantity);

  double get quantity => _quantity;

  set quantity(double value) {
    _quantity = value;
  }

  String get title => _title;

  set title(String value) {
    _title = value;
  }

  String get id => _id;

  set id(String value) {
    _id = value;
  }
}

class Recipe with ChangeNotifier {
  List<RecipeItems> _recipe = [];

  // Map<String, RecipeItems> _items = {};

  // Map<String, RecipeItems> get items {
  //   return {..._items};
  // }

  int get itemCount {
    return _recipe.length;
  }

  UnmodifiableListView<RecipeItems> get products {
    return UnmodifiableListView(_recipe);
  }

  void addRecipeItems(RecipeItems recipeItems) {
    _recipe.add(recipeItems);
    notifyListeners();
  }

  void updateRecipeItems(
      int proId, String proname, double qty, RecipeItems item) {
    item.id = proId.toString();
    item.title = proname;
    item.quantity = qty;
    notifyListeners();
  }

  // double get totalAmount {
  //   var total = 0.0;
  //   _items.forEach((key, cartItem) {
  //     total += cartItem.price * cartItem.quantity;
  //   });
  //   return total;
  // }

  // void addItem(
  //   String productId,
  //   double quantity,
  //   String title,
  // ) {
  //   _items.putIfAbsent(
  //     productId,
  //     () => RecipeItems(
  //       id: productId,
  //       title: title,
  //       quantity: quantity,
  //     ),
  //   );
  //   notifyListeners();
  // }

  void removeItem(String productId) {
    _recipe.remove(productId);
    notifyListeners();
  }

  void deleteTask(RecipeItems recipeItems) {
    _recipe.remove(recipeItems);
    notifyListeners();
  }

// void removeSingleItem(String productId) {
//   if (!_recipe.containsKey(productId)) {
//     return;
//   }
//   _recipe.remove(productId);
//   notifyListeners();
// }

  void clear() {
    _recipe.clear();
    notifyListeners();
  }
}
