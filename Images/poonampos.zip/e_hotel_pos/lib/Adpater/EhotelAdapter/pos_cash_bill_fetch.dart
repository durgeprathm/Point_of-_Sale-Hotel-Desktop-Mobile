import 'package:retailerp/NetworkHelper/network_helper.dart';
import 'package:retailerp/NetworkHelper/network_helper_hotel.dart';

class CashBillFetch {

  Future <dynamic> getCashBillFetch (String CashBill_Id) async
  {
    var map = new Map<String, dynamic>();
    map['actionId'] = CashBill_Id;

    String apifile = 'view_cash_bill.php';
    NetworkHelperHotel networkHelper = new NetworkHelperHotel(apiname: apifile,data: map);
    var cashbilldata = await networkHelper.getData();
    return cashbilldata;
  }

}