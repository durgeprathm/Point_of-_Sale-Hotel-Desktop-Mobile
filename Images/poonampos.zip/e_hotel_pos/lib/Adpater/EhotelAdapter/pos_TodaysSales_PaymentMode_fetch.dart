import 'package:retailerp/NetworkHelper/network_helper_hotel.dart';

class TodaysSalesPaymentModeFetch {

  Future <dynamic> getTodaysSalesPaymentModeFetch(String payment_id,String todays_Date) async
  {
    var map = new Map<String, dynamic>();
    map['actionId'] = "5";
    map['paymodename'] = payment_id;
    map['Paymodedate'] = todays_Date;

    String apifile = 'Day_wise_Sales_reports.php';
    NetworkHelperHotel networkHelper = new NetworkHelperHotel(apiname: apifile,data: map);
    var todaysalespaymentmodefetch = await networkHelper.getData();
    return todaysalespaymentmodefetch;
  }

}