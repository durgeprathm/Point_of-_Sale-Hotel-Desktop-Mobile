import 'package:retailerp/NetworkHelper/network_helper.dart';

class ManegeSalesPaymentModeFetch {

  Future <dynamic> getManageSalesPaymentModeFetch(String PaymentMode) async
  {
    var map = new Map<String, dynamic>();
    map['actionId'] = "0";
    map['SalesPaymentMode'] = PaymentMode;

    String apifile = 'Fetch_ManageSalesPayment_Mode.php';
    NetworkHelper networkHelper = new NetworkHelper(apiname: apifile,data: map);
    var managesalespaymentmodefetch = await networkHelper.getData();
    return managesalespaymentmodefetch;
  }

}