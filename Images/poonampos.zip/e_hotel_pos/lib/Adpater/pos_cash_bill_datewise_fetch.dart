import 'package:retailerp/NetworkHelper/network_helper.dart';

class CashBillDateWiseFetch {

  Future <dynamic> getCashBillDateWiseFetch (String DateFrom, String DateTo) async
  {
    var map = new Map<String, dynamic>();
    map['actionId'] = "1";
    map['sdate'] = DateFrom;
    map['edate'] = DateTo;

    String apifile = 'Fetch_Cash_Bill.php';
    NetworkHelper networkHelper = new NetworkHelper(apiname: apifile,data: map);
    var cashbilldata = await networkHelper.getData();
    return cashbilldata;
  }

}