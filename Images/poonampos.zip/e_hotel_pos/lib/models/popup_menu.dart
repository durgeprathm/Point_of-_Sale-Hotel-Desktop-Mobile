import 'package:flutter/material.dart';

class PopupMenu {
  final String title;
  final Icon icon;

  const PopupMenu({this.title, this.icon});


}

