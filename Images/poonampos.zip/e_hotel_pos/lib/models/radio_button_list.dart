class RadioButtonList {
  int index;
  String name;

  RadioButtonList({this.name, this.index});
}
