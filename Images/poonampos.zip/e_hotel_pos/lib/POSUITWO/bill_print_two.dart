import 'package:flutter/material.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'dart:typed_data';

class BillPrintTwo extends StatefulWidget {
  @override
  _BillPrintTwoState createState() => _BillPrintTwoState();
}

class _BillPrintTwoState extends State<BillPrintTwo> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: PdfPreview(
          build: (format) => _generatePdf(format, "title"),
        ),
      ),
    );
  }


  Future<Uint8List> _generatePdf(PdfPageFormat format, String title) async {
    final pdf = pw.Document();
    pdf.addPage(
      pw.Page(
        pageFormat: format,
        build: (context) {
          return pw.Center(
            child: pw.Text(title),
          );
        },
      ),
    );
    return pdf.save();
  }
}

