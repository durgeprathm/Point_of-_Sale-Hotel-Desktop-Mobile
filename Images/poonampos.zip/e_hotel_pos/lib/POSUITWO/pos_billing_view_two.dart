import 'package:dropdown_search/dropdown_search.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:retailerp/Const/constcolor.dart';
import 'package:retailerp/LocalDbModels/POSModels/producttwo.dart';
import 'package:retailerp/LocalDbModels/customer_model.dart';
import 'package:retailerp/POSUIONE/pos_billing.dart';
import 'package:retailerp/POSUITWO/pos_billing_list_two.dart';
import 'package:retailerp/POSUITWO/pos_billing_two.dart';
import 'package:retailerp/helpers/database_helper.dart';
import 'package:retailerp/utils/POSProviders/billing_productdatatwo.dart';
import 'PayButton_two.dart';
import 'package:retailerp/utils/const.dart';
import 'package:dropdownfield/dropdownfield.dart';
import 'package:sqflite/sqflite.dart';
import '../POSUIONE/PayButton.dart';



class POSBillingTwoView extends StatefulWidget {

  @override
  _POSBillingTwoViewState createState() => _POSBillingTwoViewState();
}

class _POSBillingTwoViewState extends State<POSBillingTwoView> {


  DateTime now = new DateTime.now();
  DateTime date;
  String _selectdate = DateFormat('dd/MM/yyyy').format(new DateTime.now());

  DatabaseHelper databaseHelper = DatabaseHelper();
  List<ProductTwo> productList;
  List<ProductTwo> tempproductList;
  List<CustomerModel> localcustomerList;
  List<String> tempcustomernamelist;
  String CustomerName;
//  Future<List<Product>> future;
  int count;
  int customercount =0;

  @override
  void initState() {
    date = new DateTime(now.year, now.month, now.day);
    updateCustomerListViewTwo();
  }


  void updateCustomerListViewTwo() {
    final Future<Database> dbFuture = databaseHelper.initializeDatabase();
    dbFuture.then((value) {
      Future<List<CustomerModel>> productListFuture =
      databaseHelper.getCustomerList();
      productListFuture.then((customerList) {
        setState(() {
          this.localcustomerList = customerList;
          this.customercount = customerList.length;
          //this._searchList = productCatList;
        });
      });
    });
  }


  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Container(
        width: 450,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              child: Row(
                children: [
                  Expanded(
                    child: Text("Billing Items",  style:
                    TextStyle(fontWeight: FontWeight.bold, fontSize: 15.0,color: PrimaryColor)),
                  ),
                  GestureDetector(
                    onTap: (){
                      Provider.of<ProductDataTwo>(context, listen: false)
                          .ClearTask();
                    },
                    child: Text("Clear All",  style:
                    TextStyle(fontWeight: FontWeight.bold, fontSize: 15.0,color: Colors.blue)),
                  ),

                ],
              ),
            ),
            Divider(
              height: 5,
              thickness: 3.0,
              color: PrimaryColor,
            ),
            ProductbillinglistTwo(),
            Divider(
              height: 5,
              thickness: 3.0,
              color: PrimaryColor,
            ),
            POSBillTwo(),
            SizedBox(
              height: 35.0,
            ),
            PayButtonTwo(CustomerName,_selectdate),
          ],
        ),
      ),
    );
  }
}