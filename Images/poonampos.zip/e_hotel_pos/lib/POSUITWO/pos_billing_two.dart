import 'package:flutter/material.dart';

import 'package:provider/provider.dart';
import 'package:retailerp/Const/constcolor.dart';
import 'package:retailerp/utils/POSProviders/billing_productdatatwo.dart';

class POSBillTwo extends StatefulWidget {
  @override
  _POSBillTwoState createState() => _POSBillTwoState();
}

class _POSBillTwoState extends State<POSBillTwo> {
  int FinalSubTotal = 0;
  @override
  Widget build(BuildContext context) {
    return Consumer<ProductDataTwo>(builder: (context, productData, child) {
      return Material(
        child: Container(
          child: Column(
            children: [
              Container(
                height: 15.0,
                child: ListTile(
                  title: Text("Sub Total"),
                  trailing: Text(productData.totalAmount1!=null?"₹${((productData.totalAmount1)-(productData.TotalGSTAmount)).toStringAsFixed(2)}":'',
                      style:
                      TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                ),
              ),
              SizedBox(
                height: 13.0,
              ),
              Container(
                height: 15.0,
                child: ListTile(
                  title: Text("SGST"),
                  trailing: Text("$Rupees${(productData.TotalGSTAmount/2).toStringAsFixed(2)}",
                      style:
                      TextStyle(fontWeight: FontWeight.bold, fontSize: 15))
                  ),
                  ),
              SizedBox(
                height: 13.0,
              ),
              Container(
                height: 15.0,
                child: ListTile(
                  title: Text("CGST"),
                    trailing: Text("$Rupees${(productData.TotalGSTAmount/2).toStringAsFixed(2)}",
                        style:
                        TextStyle(fontWeight: FontWeight.bold, fontSize: 15))
                ),
              ),
              SizedBox(
                height: 13.0,
              ),
              Container(
                height: 15.0,
                child: ListTile(
                  title: Text(
                    "Grand Total",
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  trailing: Text("₹${productData.totalAmount1.toString()}",
                      style:
                      TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                ),
              ),
            ],
          ),
        ),
      );
    });
  }
}
