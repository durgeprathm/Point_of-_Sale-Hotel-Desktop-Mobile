import 'dart:io';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:retailerp/Const/constcolor.dart';
import 'package:provider/provider.dart';
import 'package:retailerp/utils/POSProviders/billing_productdatatwo.dart';

class ProductbillinglistTwo extends StatefulWidget {

  @override
  _ProductbillinglistTwoState createState() => _ProductbillinglistTwoState();
}

class _ProductbillinglistTwoState extends State<ProductbillinglistTwo> {

  List<int> mytempsubTotal = new List();
  double updatedPrice;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: 5),
      child: Consumer<ProductDataTwo>(
          builder: (context, productData, child) {
            return Container(
              height: 220,
              child: ListView.builder(
                itemCount: productData.productCount,
                shrinkWrap: true,
                scrollDirection: Axis.vertical,
                itemBuilder: (context, int index) {
                  final product = productData.products[index];
                  return Padding(
                    padding: const EdgeInsets.all(2.0),
                    child: Material(
                      elevation: 3.0,
                      child: Container(
                        height: 70,
                        child: Row(
                          children: [
                            SizedBox(
                              width: 2.0,
                            ),
                            Expanded(
                              child: Container(
                                  child: ListTile(
                                    title: Text(product.productname),
                                    subtitle: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Padding(
                                          padding: const EdgeInsets.only(top: 3.0,bottom: 3.0),
                                          child: Text("Basic Amt: $Rupees${productData.getBasicAmount(product).toStringAsFixed(2)}",style: TextStyle(fontStyle: FontStyle.italic),),
                                        ),
                                        Padding(
                                          padding: const EdgeInsets.only(top: 3.0,bottom: 3.0),
                                          child: Text("GST : ${product.gstperce}% : $Rupees${productData.getGSTAmount(product).toStringAsFixed(2)}",style: TextStyle(fontStyle: FontStyle.italic),),
                                        ),
                                      ],
                                    ),
                                  )),
                            ),
                            Expanded(
                              child: Container(
                                  child: Row(
                                    children: [
                                      Padding(
                                        padding:
                                        EdgeInsets.all(5.0),
                                        child: IconButton(
                                          icon: FaIcon(
                                              product.productquntity == 1 ? FontAwesomeIcons.trash :
                                              FontAwesomeIcons
                                                  .minusCircle,
                                              color: product.productquntity == 1 ? Colors.red:
                                              ProductbtnColor),
                                          onPressed: () {
                                            productData.decreaseQuant(product);
                                            productData.decupdateSTotal(product);
                                            productData.fungetFinalSubtotalminus(product);
                                            if(product.productquntity < 1){
                                              productData.deleteTask(product);
                                            }
                                          },
                                        ),
                                      ),
                                      Padding(
                                          padding:
                                          EdgeInsets.all(2.0),
                                          child: Text(product.productquntity.toString())),
                                      Padding(
                                        padding:
                                        EdgeInsets.all(2.0),
                                        child: IconButton(
                                          icon: FaIcon(
                                            FontAwesomeIcons
                                                .plusCircle,
                                            color: ProductbtnColor,
                                          ),
                                          onPressed: () {
                                            productData.increaseQuant(product);
                                            productData.updateSTotal(product);
//                                        mytempsubTotal.insert(index,product.subTotal);
                                            print(mytempsubTotal);
//                                        productData.funfinalSubtotal(product);
                                          },
                                        ),
                                      ),
                                      SizedBox(
                                        width: 5.0,
                                      ),
                                      Padding(
                                          padding:
                                          EdgeInsets.all(10),
                                          child:
                                          Text(product.subTotal.toString())
                                      ),
                                      GestureDetector(
                                        child: Padding(
                                          padding: EdgeInsets.all(5),
                                          child:Icon(
                                            Icons.edit,
                                            color: Colors.blue,
                                          ),

                                        ),
                                        onTap: () {
                                          setState(()  {
                                            showDialog<void>(
                                              context: context,
                                              barrierDismissible: false, // user must tap button!
                                              builder: (BuildContext context) {
                                                return SingleChildScrollView(
                                                  child:  AlertDialog(
                                                    title: Text('Enter Price'),
                                                    content: SingleChildScrollView(
                                                      child: ListBody(
                                                        children: <Widget>[
                                                          TextField(
                                                            autofocus: true,
                                                            textAlign: TextAlign.left,
                                                            keyboardType: TextInputType.number,
                                                            decoration: InputDecoration(
                                                                labelText: "Price"
                                                            ),
                                                            onChanged: (newText) {
                                                              updatedPrice = double.parse(newText);
                                                            },
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    actions: <Widget>[
                                                      TextButton(
                                                        child: Text('Add'),
                                                        onPressed: () {
                                                          Navigator.of(context).pop();
                                                          productData.updatePrice(updatedPrice,product);
                                                        },
                                                      ),
                                                    ],
                                                  ),
                                                );
                                              },
                                            );
                                          });
                                        },
                                      )
                                    ],
                                  )),
                            )
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
            );
          }),
    );
  }
}


//Padding(
//padding: EdgeInsets.only(bottom: 5),
//child: Consumer<ProductData>(
//builder: (context, productData, child) {
//return Container(
//height: 160,
//child: ListView.builder(
//itemCount: productData.productCount,
//shrinkWrap: true,
//scrollDirection: Axis.vertical,
//itemBuilder: (context, int index) {
//final product =
//productData.products[index];
//return Container(
//child: Row(
//children: [
//SizedBox(
//width: 2.0,
//),
//Expanded(
//child: Container(
//child: ListTile(
//title: Text(product.productname),
//subtitle: Text(product
//    .productprice
//    .toString()),
//)),
//),
//Expanded(
//child: Container(
//child: Row(
//children: [
//Padding(
//padding:
//EdgeInsets.all(5.0),
//child: IconButton(
//icon: FaIcon(
//product.productquntity == 1 ? FontAwesomeIcons.trash :
//FontAwesomeIcons
//    .minusCircle,
//color: product.productquntity == 1 ? Colors.red:
//ProductbtnColor),
//onPressed: () {
//productData.decreaseQuant(product);
//productData.decupdateSTotal(product);
//if(product.productquntity < 1){
//productData.deleteTask(product);
//}
//},
//),
//),
//Padding(
//padding:
//EdgeInsets.all(5.0),
//child: Text(product.productquntity.toString())),
//Padding(
//padding:
//EdgeInsets.all(5.0),
//child: IconButton(
//icon: FaIcon(
//FontAwesomeIcons
//    .plusCircle,
//color: ProductbtnColor,
//),
//onPressed: () {
//productData.increaseQuant(product);
//productData.updateSTotal(product);
//},
//),
//),
//SizedBox(
//width: 15.0,
//),
//Padding(
//padding:
//EdgeInsets.all(10),
//child:
//Text(product.subTotal.toString()))
//],
//)),
//)
//],
//),
//);
//},
//),
//);
//}),
//);