import 'dart:io';
import 'package:dropdown_search/dropdown_search.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:retailerp/Adpater/fetch_menuList.dart';
import 'package:retailerp/Const/constcolor.dart';
import 'package:retailerp/LocalDbModels/POSModels/producttwo.dart';
import 'package:retailerp/LocalDbModels/product_model.dart';
import 'package:retailerp/Repository/repository_service_retailerp.dart';
import 'package:retailerp/helpers/database_helper.dart';
import 'package:retailerp/utils/POSProviders/billing_productdatatwo.dart';
import 'package:retailerp/utils/const.dart';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';

class POSProductViewerTwo extends StatefulWidget {

  @override
  _POSProductViewerTwoState createState() => _POSProductViewerTwoState();
}

class _POSProductViewerTwoState extends State<POSProductViewerTwo> {
  Icon actionIcon = Icon(
    Icons.search,
    color: Colors.orange,
  );
  bool _IsSearching;
  String _searchText = "";
  List<ProductModel> _searchList = List();

  //----------------------For fetching menu list from server--------------------------//
  List<ServerMenuModel> productCatListServer = [];
  List<ServerMenuModel> _searchListServer = [];
  TextEditingController SerachController = new TextEditingController();
  MenuList menuList = new MenuList();



//----------------------For fetching menu list from Local database--------------------------//
  DatabaseHelper databaseHelper = DatabaseHelper();
  List<ProductModel> productCatList;
  int count = 0;


  @override
  void initState() {
    super.initState();
    _getMenu();
  }


  void _getMenu() async {

    print("Inside getmenu");
    var productData = await menuList.getMenu("1");
    var resid = productData["resid"];
    var productsd = productData["menu"];
    int tempChecking = productData["rowcount"];
    print(tempChecking);
    List<ServerMenuModel> products = [];

    if(productsd != null){
      for (var n in productsd) {
        ServerMenuModel pro = ServerMenuModel(n["MenuId"], n["MenuName"], n["Menucategory"],
            n["MenuRate"],n["MenuGST"]);
        products.add(pro);
      }
    }
    setState(() {
      this.productCatListServer = products;
      this._searchListServer = productCatListServer;
      this.count = productCatListServer.length;
    });

    SerachController.addListener(() {
      setState(() {
        if(productCatListServer != null){
          String s = SerachController.text;
          _searchListServer = productCatListServer.where((element) => element.pname.toLowerCase().contains(s.toLowerCase())).toList();
        }
      });
    });
  }



  //---------Fetch Menu from Local databse---------------//
  // void updateListViewTwo() {
  //   final Future<Database> dbFuture = databaseHelper.initializeDatabase();
  //   dbFuture.then((value) {
  //     Future<List<ProductModel>> productListFuture =
  //     databaseHelper.getProductList();
  //     productListFuture.then((productCatList) {
  //       setState(() {
  //         this.productCatList = productCatList;
  //         this._searchList = productCatList;
  //         this.count = productCatList.length;
  //       });
  //     });
  //   });
  //
  // }


  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(
            children: [
              Padding(
                  padding: EdgeInsets.all(3),
                  child: Text(
                    "Menu",
                    style:
                    TextStyle(fontWeight: FontWeight.bold, fontSize: 15.0,color: PrimaryColor),
                  )
              ),
              SizedBox(
                width: 65.0,
              ),
              Expanded(
                child: Container(
                  child: TextField(
                    style: TextStyle(
                      color: Colors.blueGrey,
                    ),
                    controller: SerachController,
                    decoration: InputDecoration(
                        hintText: "Start typing menu name here....",
                        suffixIcon: IconButton(
                          icon: Icon(Icons.search),
                          color: Colors.orange,
                          onPressed: () {
                          },
                        )
                    ),
                  ),
                ),
              )
            ],
          ),
          Expanded(
            child: Consumer<ProductDataTwo> (builder: (context, productData, child) {
              return Container(
                height: 350,
                child: _searchListServer.length == 0
                    ? Center(
                  child: CircularProgressIndicator(),
                )
                    : GridView.builder(
                    itemCount: _searchListServer.length,
                    shrinkWrap: true,
                    itemBuilder: (context, index) {
                      return Padding(
                        padding: EdgeInsets.all(10.0),
                        child: GestureDetector(
                          onTap: () {
//                          final product = Product.copyWith(
//                              "Apple",
//                              20,
//                              250,
//                              1,
//                              "27/10/20",
//                              "28/10/20",
//                              0,
//                              250,
//                              0);
//                            final product = Product.copyWith("Apple", 20, 250, 1,
//                                "27/10/20", "28/10/20", 0, 250, 0);
                            final product = ProductTwo.copyWith(
                                _searchListServer[index].pname,
                                20,
                                double.parse(_searchListServer[index].productrate),
                                1,
                                "27/10/20",
                                "28/10/20",
                                0,
                                double.parse(_searchListServer[index].productrate),
                                double.parse(_searchListServer[index].productrate),
                                "",
                                double.parse(_searchListServer[index].GSTPer)
                            );
                            Provider.of<ProductDataTwo>(context, listen: false)
                                .addProduct(product);

//                             final pro = productData.products;
//                             List<ProductTwo> newProductlist = pro;
//                             if (newProductlist.length == 0) {
//
//                               Provider.of<ProductDataTwo>(context, listen: false)
//                                   .addProduct(product);
//
//
//                             } else {
//                               for (int i = 0; i < newProductlist.length; i++) {
//                                 if (newProductlist[i].productname != productCatList[index].proName) {
//                                   print("i value$i");
//                                   print("index value$index");
//                                   print("1///${newProductlist[i].productname}");
//                                   print("2///${productCatList[index].proName}");
//                                   Provider.of<ProductDataTwo>(context, listen: false)
//                                       .addProduct(product);
//                                   i = newProductlist.length + 1;
//                                   print("After initlize$i");
//                                   break;
//                                 } else {
//                                   print("else i value$i");
//                                   print("else index value$index");
//                                   print("else 1///${newProductlist[i].productname}");
//                                   print("else 2///${productCatList[index].proName}");
//                                   Provider.of<ProductDataTwo>(context, listen: false)
//                                       .increaseQuant(product);
//                                   Provider.of<ProductDataTwo>(context, listen: false)
//                                       .updateSTotal(product);
// //                                  productData.increaseQuant(product);
// //                                  productData.updateSTotal(product);
//                                   print('Already Exists');
//                                   break;
//                                 }
//                               }
//                             }
//                            final pro = productData.products;
//                            List<Product> newProductlist = pro;
//                            if (newProductlist.length == 0) {
//                              Provider.of<ProductData>(context, listen: false)
//                                  .addProduct(product);
//                            } else {
//                              for (int i = 0; i < newProductlist.length; i++) {
//                                print(newProductlist[i].productname);
//                                print(productCatList[index].proName);
//
//                                for (int j = 0; j < productCatList.length; j++) {
//                                  if (newProductlist[i].productname ==
//                                      (productCatList[j].proName)) {
//                                    print('Already Exists');
//                                  } else {
//                                    print('else Call');
//                                  }
//                                }
////                              if (newProductlist[i].productname == productCatList[index].proName) {
////                                print('Already Exists');
////                                Provider.of<ProductData>(context, listen: false)
////                                    .addProduct(product);
////                                break;
////                              } else {
////                                print('else Call');
////                                productData.increaseQuant(product);
////                                productData.updateSTotal(product);
////                                print('Already Exists');
////                                break;
////                              }
                          },
                          child: Material(
                            borderRadius: BorderRadius.circular(5.0),
                            elevation: 5.0,
                            child: Container(
                                child: Column(
                                  children: [
                                    ListTile(
                                      title: Text(_searchListServer[index].pname,
                                          style: TextStyle(
                                            color: Colors.black,
                                          )),
                                      subtitle: Text(
                                        _searchListServer[index].productrate
                                            .toString(),
                                        style: TextStyle(
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold),
                                      ),
                                    ),
                                  ],
                                )),
                          ),
                        ),
                      );
                    },
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 3,
                      childAspectRatio: 2.0,
                    )),
              );
            }),
          )
        ]),
      ),
    );
  }

}


class ProductCatViewTwo extends StatefulWidget {
  @override
  _ProductCatViewTwoState createState() => _ProductCatViewTwoState();
}

class _ProductCatViewTwoState extends State<ProductCatViewTwo> {
  List<bool> catgeorySelction = [false, false, false];

  List<bool> subCatSelction = [
    false,
    false,
    false,
    false,
    false,
    false,
  ];

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
            padding: EdgeInsets.only(top: 8, bottom: 4),
            child: Text(
              "Filters",
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15.0,color: PrimaryColor),
            )),
        Container(
          child: Row(
              children: [
                Padding(
                  padding: const EdgeInsets.only(bottom: 5.0),
                  child: Material(
                    child: Container(
                        height: 30,
                        child: ListView.builder(
                            shrinkWrap: true,
                            scrollDirection: Axis.horizontal,
                            itemCount: 3,
                            itemBuilder: (BuildContext context, int index) {
                              return Row(
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.all(5.0),
                                    child: Switch(
                                      value: catgeorySelction[index],
                                      onChanged: (value) {
                                        setState(() {
//                                    isSwitched = value;
                                          catgeorySelction[index] = value;
                                          print(value.toString());
                                        });
                                      },
                                      activeTrackColor: Colors.blue,
                                      activeColor: Colors.blueGrey,
                                    ),
                                  ),
                                  Text(
                                    category[0]['category'][index]['catname'],
                                  ),
                                  SizedBox(
                                    width: 8.0,
                                  )
                                ],
                              );
                            })),
                  ),
                ),
                Container(
                  width: 180,
                  height: 50,
                  child: Padding(
                    padding: const EdgeInsets.all(3.0),
                    child: DropdownSearch(
                      items: ["Item 1","Item 2","Item 3","Item 4","Item 5",],
                      label: "Select SubCat",
                      onChanged: (item) {
                        setState(() {
                          // CustomerName = item;
                          // print(CustomerName);
                        });
                      },
                    ),
                  ),
                ),
              ]
          ),
        ),
        SizedBox(
          height: 5.0,
        )
      ],
    );
  }
}
class ServerMenuModel{
  String pid;
  String pname;
  String productcatid;
  String productrate;
  String GSTPer;

  ServerMenuModel(this.pid, this.pname, this.productcatid, this.productrate,this.GSTPer);
}
