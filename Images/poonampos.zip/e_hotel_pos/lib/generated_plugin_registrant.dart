//
// Generated file. Do not edit.
//

import 'package:connectivity_for_web/connectivity_for_web.dart';
import 'package:file_picker/src/file_picker_web.dart';
import 'package:fluttertoast/fluttertoast_web.dart';
import 'package:printing/src/printing_web.dart';
import 'package:shared_preferences_web/shared_preferences_web.dart';

import 'package:flutter_web_plugins/flutter_web_plugins.dart';

// ignore: public_member_api_docs
void registerPlugins(Registrar registrar) {
  ConnectivityPlugin.registerWith(registrar);
  FilePickerWeb.registerWith(registrar);
  FluttertoastWebPlugin.registerWith(registrar);
  PrintingPlugin.registerWith(registrar);
  SharedPreferencesPlugin.registerWith(registrar);
  registrar.registerMessageHandler();
}
