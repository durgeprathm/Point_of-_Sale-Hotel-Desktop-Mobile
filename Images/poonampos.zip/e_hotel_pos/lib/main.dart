import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:retailerp/EhotelModel/StockTransfer.dart';
import 'package:retailerp/models/purchase_model.dart';
import 'package:retailerp/models/sales_model.dart';
import 'package:retailerp/models/supplier.dart';
import 'package:retailerp/pages/splashscreen.dart';
import 'package:retailerp/providers/recipe.dart';
import 'package:retailerp/utils/MobilePOSProviders/billing_productMobile.dart';
import 'package:retailerp/utils/POSProviders/billing_productdata.dart';
import 'package:retailerp/utils/POSProviders/billing_productdatatwo.dart';
import './utils/material_color_generator.dart';
import './utils/const.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    MaterialColor primarySwatch = generateMaterialColor(primary);
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (context) => ProductData()),
        ChangeNotifierProvider(create: (context) => ProductDataTwo()),
        ChangeNotifierProvider(create: (context) => ProductDataMobile()),
        ChangeNotifierProvider(create: (context) => PurchaseModel()),
        ChangeNotifierProvider(create: (context) => SalesModel()),
        ChangeNotifierProvider(create: (context) => Recipe()),
        ChangeNotifierProvider(create: (context) => SupplierProvider()),
        ChangeNotifierProvider(create: (context) => StockTranferProvider())
      ],
      child: MaterialApp(
        title: 'Poonam POS',
        theme: ThemeData(
            primarySwatch: primarySwatch,
            accentColor: PrimaryColor,
            visualDensity: VisualDensity.adaptivePlatformDensity,
            fontFamily: 'Poppins-Medium'),
        debugShowCheckedModeBanner: false,
        home: SplashScreen(),
      ),
    );
  }
}
