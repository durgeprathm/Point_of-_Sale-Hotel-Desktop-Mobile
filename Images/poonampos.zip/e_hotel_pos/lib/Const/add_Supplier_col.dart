const AddSupplierTable = 'tbl_Supplier_table';
const Supplierid = 'Supplier_id';
const SupplierComapanyName = 'Supplier_Comapany_Name';
const SupplierComapanyPersonName = 'Supplier_Comapany_Person_Name';
const SupplierMobile = 'Supplier_Mobile';
const SupplierEmail = 'Supplier_Email';
const SupplierAddress = 'Supplier_Address';
const SupplierUdyogAadhar = 'Supplier_Udyog_Aadhar';
const SupplierCINNumber = 'Supplier_CIN_Number';
const SupplierGSTType = 'Supplier_GST_Type';
const SupplierGSTNumber = 'Supplier_GST_Number';
const SupplierFAXNumber = 'Supplier_FAX_Number';
const SupplierPANNumber = 'Supplier_PAN_Number';
const SupplierLicenseType = 'Supplier_License_Type';
const SupplierLicenseName = 'Supplier_License_Name';
const SupplierBankName = 'Supplier_Bank_Name';
const SupplierBankBranch = 'Supplier_Bank_Branch';
const SupplierAccountType = 'Supplier_Account_Type';
const SupplierAccountNumber = 'Supplier_Account_Number';
const SupplierIFSCCode = 'Supplier_IFSC_Code';
const SupplierUPINumber = 'Supplier_UPI_Number';


