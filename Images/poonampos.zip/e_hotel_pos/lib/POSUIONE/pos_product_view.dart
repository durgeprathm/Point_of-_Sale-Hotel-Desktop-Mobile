import 'dart:io';
import 'package:dropdown_search/dropdown_search.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:retailerp/Adpater/fetch_menuList.dart';
import 'package:retailerp/Adpater/pos_product_fetch.dart';
import 'package:retailerp/Const/constcolor.dart';
import 'package:retailerp/LocalDbModels/POSModels/product.dart';
import 'package:retailerp/LocalDbModels/product_model.dart';
import 'package:retailerp/Repository/repository_service_retailerp.dart';
import 'package:retailerp/helpers/database_helper.dart';
import 'package:retailerp/utils/POSProviders/billing_productdata.dart';
import 'package:retailerp/utils/const.dart';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';

class POSProductViewer extends StatefulWidget {

  @override
  _POSProductViewerState createState() => _POSProductViewerState();
}

class _POSProductViewerState extends State<POSProductViewer> {
  Icon actionIcon = Icon(
    Icons.search,
    color: Colors.orange,
  );
  //----------------------For fetching menu list from local db--------------------------//

  List<ProductModel> _searchList = List();
  List<ProductModel> productCatList;

  //----------------------For fetching menu list from server--------------------------//
  List<ServerMenuModel> productCatListServer = [];
  List<ServerMenuModel> _searchListServer = [];
  MenuList menuList = new MenuList();
  TextEditingController SerachController = new TextEditingController();



  final TextEditingController _searchQuery = TextEditingController();
  DatabaseHelper databaseHelper = DatabaseHelper();

  int count = 0;


  @override
  void initState() {
    // _getProducts();
    _getMenu();

  }


  void _getMenu() async {

    print("Inside getmenu");
    var productData = await menuList.getMenu("1");
    var resid = productData["resid"];
    var productsd = productData["menu"];
    int tempChecking = productData["rowcount"];
    print(tempChecking);
    List<ServerMenuModel> products = [];

    if(productsd != null){
      for (var n in productsd) {

        ServerMenuModel pro = ServerMenuModel(n["MenuId"], n["MenuName"], n["Menucategory"],
            n["MenuRate"],n["MenuGST"]);
        products.add(pro);
      }

    }
    setState(() {
      this.productCatListServer = products;
      this._searchListServer = productCatListServer;
      this.count = productCatListServer.length;
    });

    SerachController.addListener(() {
      setState(() {
        if(productCatListServer != null){
          String s = SerachController.text;
          _searchListServer = productCatListServer.where((element) => element.pname.toLowerCase().contains(s.toLowerCase())).toList();
        }
      });
    });
  }

  //local database fetch

  // void updateListView() {
  //   final Future<Database> dbFuture = databaseHelper.initializeDatabase();
  //   dbFuture.then((value) {
  //     Future<List<ProductModel>> productListFuture =
  //     databaseHelper.getProductList();
  //     productListFuture.then((productCatList) {
  //       setState(() {
  //         this.productCatList = productCatList;
  //         this._searchList = productCatList;
  //         this.count = productCatList.length;
  //       });
  //     });
  //   });
  //
  //   SerachController.addListener(() {
  //     setState(() {
  //      if(productCatList != null){
  //        String s = SerachController.text;
  //        _searchList = productCatList.where((element) => element.proComName.toLowerCase().contains(s.toLowerCase())).toList();
  //      }
  //     });
  //   });
  // }

  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          ProductCatView(),
          Row(
            children: [
              Padding(
                  padding: EdgeInsets.all(3),
                  child: Text(
                    "Menu",
                    style:
                        TextStyle(fontWeight: FontWeight.bold, fontSize: 15.0,color: PrimaryColor),
                  )
              ),
              SizedBox(
                width: 45.0,
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(right: 12.0),
                  child: Container(
                    child: TextField(
                      controller: SerachController,
                      style: TextStyle(
                        color: Colors.blueGrey,
                      ),
                      decoration: InputDecoration(
                       hintText: "Start typing menu here..",
                        suffixIcon: IconButton(
                       icon: Icon( Icons.search),
                        color: PrimaryColor,
                          onPressed: () {
                          },
                      )
                      ),
                    ),
                  ),
                ),
              )
            ],
          ),
          SizedBox(
            height: 10.0,
          ),
          Expanded(
            child: Consumer<ProductData> (builder: (context, productData, child) {
              return Container(
                height: 400,
                child: _searchListServer.length == 0
                    ? Center(child: CircularProgressIndicator())
                    : GridView.builder(
                    itemCount: _searchListServer.length,
                    shrinkWrap: true,
                    itemBuilder: (context, index) {
                      return Padding(
                        padding: EdgeInsets.all(10.0),
                        child: GestureDetector(
                          onTap: () {
//                          final product = Product.copyWith(
//                              "Apple",
//                              20,
//                              250,
//                              1,
//                              "27/10/20",
//                              "28/10/20",
//                              0,
//                              250,
//                              0);
//                            final product = Product.copyWith("Apple", 20, 250, 1,
//                                "27/10/20", "28/10/20", 0, 250, 0);
                            final product = Product.copyWith(
                                int.parse(_searchListServer[index].pid),
                                _searchListServer[index].pname,
                                double.parse(_searchListServer[index].productrate),
                                1,
                                0,
                                double.parse(_searchListServer[index].productrate),
                                double.parse(_searchListServer[index].productrate),
                                double.parse(_searchListServer[index].GSTPer));

                            Provider.of<ProductData>(context, listen: false)
                                .addProduct(product);


                            // if(productData.productCount !=0){
                            //   print("Count1 ${productData.productCount}");
                            //   for(int i=0;i<productData.productCount;i++){
                            //     print("i---$i");
                            //     if(productData.products[i].productname !=  _searchListServer[index].pname){
                            //       Provider.of<ProductData>(context, listen: false)
                            //           .addProduct(product);
                            //       print("Count2 ${productData.productCount}");
                            //     }
                            //   }
                            // }else{
                            //   Provider.of<ProductData>(context, listen: false)
                            //       .addProduct(product);
                            //   print("else count ${productData.productCount}");
                            // }


                           //// ////////////----------------------------------------------///////////////////
//                             final pro = productData.products;
//                             List<Product> newProductlist = pro;
//                             if (newProductlist.length == 0) {
//
//                               Provider.of<ProductData>(context, listen: false)
//                                   .addProduct(product);
//
//
//                             } else {
//                               for (int i = 0; i < newProductlist.length; i++) {
//                                 if (newProductlist[i].productname != productCatList[index].proName) {
//                                   print("i value$i");
//                                   print("index value$index");
//                                   print("1///${newProductlist[i].productname}");
//                                   print("2///${productCatList[index].proName}");
//                                   Provider.of<ProductData>(context, listen: false)
//                                       .addProduct(product);
//                                   i = newProductlist.length + 1;
//                                   print("After initlize$i");
//                                   break;
//                                 } else {
//                                   print("else i value$i");
//                                   print("else index value$index");
//                                   print("else 1///${newProductlist[i].productname}");
//                                   print("else 2///${productCatList[index].proName}");
//                                   Provider.of<ProductData>(context, listen: false)
//                                       .increaseQuant(product);
//                                   Provider.of<ProductData>(context, listen: false)
//                                       .updateSTotal(product);
// //                                  productData.increaseQuant(product);
// //                                  productData.updateSTotal(product);
//                                   print('Already Exists');
//                                   break;
//                                 }
//                               }
//                             }
//                            final pro = productData.products;
//                            List<Product> newProductlist = pro;
//                            if (newProductlist.length == 0) {
//                              Provider.of<ProductData>(context, listen: false)
//                                  .addProduct(product);
//                            } else {
//                              for (int i = 0; i < newProductlist.length; i++) {
//                                print(newProductlist[i].productname);
//                                print(productCatList[index].proName);
//
//                                for (int j = 0; j < productCatList.length; j++) {
//                                  if (newProductlist[i].productname ==
//                                      (productCatList[j].proName)) {
//                                    print('Already Exists');
//                                  } else {
//                                    print('else Call');
//                                  }
//                                }
////                              if (newProductlist[i].productname == productCatList[index].proName) {
////                                print('Already Exists');
////                                Provider.of<ProductData>(context, listen: false)
////                                    .addProduct(product);
////                                break;
////                              } else {
////                                print('else Call');
////                                productData.increaseQuant(product);
////                                productData.updateSTotal(product);
////                                print('Already Exists');
////                                break;
////                              }
                          },
                          child: Material(
                            borderRadius: BorderRadius.circular(5.0),
                            elevation: 5.0,
                            child: Container(
                                child: Column(
                                  children: [
                                    ListTile(
                                      title: Text(_searchListServer[index].pname,
                                          style: TextStyle(
                                            color: Colors.black,
                                          )),
                                      subtitle: Text(
                                        "$Rupees${_searchListServer[index].productrate.toString()}",
                                        style: TextStyle(
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold),
                                      ),
                                    ),
                                  ],
                                )),
                          ),
                        ),
                      );
                    },
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 3,
                      childAspectRatio: 2.0,
                    )
                ),
              );
            }),
          )

        ]),
      ),
    );
  }




}


class ProductCatView extends StatefulWidget {
  @override
  _ProductCatViewState createState() => _ProductCatViewState();
}

class _ProductCatViewState extends State<ProductCatView> {
  List<bool> catgeorySelction = [false, false, false];

  List<bool> subCatSelction = [
    false,
    false,
    false,
    false,
    false,
    false,
  ];

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Padding(
        //     padding: EdgeInsets.only(bottom: 3),
        //     child: Text(
        //       "Sub Category",
        //       style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15.0, color: PrimaryColor),
        //     )),
        // Material(
        //   child: Container(
        //       height: 30,
        //       child: ListView.builder(
        //         shrinkWrap: true,
        //         scrollDirection: Axis.horizontal,
        //         itemCount: 6,
        //         itemBuilder: (BuildContext context, int index) => Row(
        //           children: [
        //             Checkbox(
        //                 value: subCatSelction[index],
        //                 onChanged: (bool value) {
        //                   setState(() {
        //                     subCatSelction[index] = value;
        //                   });
        //                 }),
        //             Text("Product $index"),
        //             SizedBox(
        //               width: 8.0,
        //             )
        //           ],
        //         ),
        //       )),
        // ),
      ],
    );
  }
}

class ServerProductModel{
  String pid;
  String pname;
  String productcatid;
  String productrate;
  String productqty;
  String productimg;

  ServerProductModel(this.pid, this.pname, this.productcatid, this.productrate,
      this.productqty, this.productimg);
}


class ServerMenuModel{
  String pid;
  String pname;
  String productcatid;
  String productrate;
  String GSTPer;


  ServerMenuModel(this.pid, this.pname, this.productcatid, this.productrate,this.GSTPer);
}