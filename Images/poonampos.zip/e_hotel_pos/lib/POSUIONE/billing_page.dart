import 'package:dropdown_search/dropdown_search.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:provider/provider.dart';
import 'package:retailerp/Adpater/EhotelAdapter/POS_Sales_Insert.dart';
import 'package:retailerp/Adpater/EhotelAdapter/pos_shop_fetch.dart';
import 'package:retailerp/Adpater/insert_walkinCustomer.dart';
import 'package:retailerp/Adpater/pos_customer-fetch.dart';
import 'package:retailerp/Const/constcolor.dart';
import 'package:retailerp/EhotelModel/Shop.dart';
import 'package:retailerp/LocalDbModels/customer_model.dart';
import 'package:retailerp/POSUIONE/pos_frontpage.dart';
import 'package:retailerp/helpers/database_helper.dart';
import 'package:retailerp/utils/POSProviders/billing_productdata.dart';
import 'package:retailerp/utils/const.dart';
import 'package:sqflite/sqflite.dart';
import 'bill_print.dart';

enum PaymentMode { cash, debit, upi }

class BillingScreen extends StatefulWidget {
  BillingScreen(this.billingAmount, this.CustomerName, this.DATE);

  final double billingAmount;
  final String CustomerName;
  final String DATE;

  @override
  _BillingScreenState createState() => _BillingScreenState();
}

class _BillingScreenState extends State<BillingScreen> {
  PaymentMode _paymode = PaymentMode.cash;
  String Paymentmode;

  List<int> ProductID = new List();
  List<String> ProductName = new List();
  List<double> RATE = new List();
  List<int> Quant = new List();
  List<double> ProSubtotal = new List();
  List<double> GSTPER = new List();

  bool cards = false;
  String TypeCard;
  String CardName;
  String DebitCardNumber;
  String DebitCardOnName;
  String UPIBankName;
  String UPITransactionId;
  List<String> DebitCards = [
    "Mastercard Cards",
    "Visa Cards",
    "RuPay Cards",
    "Maestro Cards",
    "Contactless Cards",
    "Visa Electron Cards"
  ];
  List<String> CreditCards = [
    "Student Credit cards",
    "Subprime Credit cards",
    "Secured Credit cards",
    "Balance transfer Credit cards",
    "Travel Credit cards",
    "Titanium Credit cards"
  ];

  final posFrontPage = POSFrontPage();

  List<CustomerModel> localcustomerList;
  List<String> servercustomerList;
  DatabaseHelper databaseHelper = DatabaseHelper();
  int customercount = 0;
  String CustomerName;

  bool cashView = true;
  bool debitView = false;
  bool upiView = false;
  bool custView = false;

  int discountprice = 0;
  int discountvalue;
  double total_amount;
  double payableamount;
  WalkinCustomer walkinCustomer = new WalkinCustomer();
  SalesInsert salesInsert = new SalesInsert();
  CustomerFetch customerfetch = new CustomerFetch();

  Future<void> _showMyDialog(String msg, Color col) async {
    return showDialog<void>(
      context: context,
      barrierDismissible: false, // user must tap button!
      builder: (BuildContext context) {
        return SingleChildScrollView(
          child: AlertDialog(
            title: Text(
              msg,
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: col,
              ),
            ),
            content: SingleChildScrollView(
              child: ListBody(
                children: <Widget>[],
              ),
            ),
            actions: <Widget>[
              TextButton(
                child: Text('OK'),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
            ],
          ),
        );
      },
    );
  }

  Future<void> serverCustomerList() async {
    var response = await customerfetch.getCustomerFetch("1");
    var customerSD = response["customer"];
    List<CustomerModel> tempcustomerList = [];
    List<String> tempCustoNames = [];
    for (var n in customerSD) {
      CustomerModel cust = new CustomerModel(
          n["CustomerDate"],
          n["CustomerName"],
          n["CustomerMobNo"],
          n["CustomerEmail"],
          n["CustomerAddress"],
          n["CustomerCreditType"],
          n["CustomerTaxSupplier"],
          int.parse(n["CustomerType"]));
      tempcustomerList.add(cust);
    }

    tempcustomerList.forEach((element) {
      tempCustoNames.add(element.custName);
    });

    setState(() {
      servercustomerList = tempCustoNames;
    });
  }

  void updateCustomerListView() {
    final Future<Database> dbFuture = databaseHelper.initializeDatabase();
    dbFuture.then((value) {
      Future<List<CustomerModel>> productListFuture =
          databaseHelper.getCustomerList();
      productListFuture.then((customerList) {
        setState(() {
          this.localcustomerList = customerList;
          this.customercount = customerList.length;
          //this._searchList = productCatList;
        });
      });
    });
  }

  List<String> getCustomerNames() {
    List<String> tempclist = List();
    if (customercount != 0) {
      for (int i = 0; i < localcustomerList.length; i++) {
        tempclist.add(localcustomerList[i].custName.toString());
      }
    }
    return tempclist;
  }

  @override
  void initState() {
    serverCustomerList();
    setState(() {
      payableamount = widget.billingAmount;
      total_amount = widget.billingAmount;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<ProductData>(builder: (context, productData, child) {
      return Container(
        color: Color(0xff757575),
        child: Container(
          padding: EdgeInsets.all(20.0),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(20.0),
              topRight: Radius.circular(20.0),
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Padding(
                padding: const EdgeInsets.all(3.0),
                child: Container(
                  height: 50,
                  child: Row(
                    children: [
                      Container(
                        width: 300,
                        child: Padding(
                          padding: const EdgeInsets.all(3.0),
                          child: DropdownSearch(
                            items: servercustomerList,
                            label: "Select Customer",
                            onChanged: (item) {
                              setState(() {
                                CustomerName = item;
                                print(CustomerName);
                              });
                            },
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 10.0,
                      ),
                      IconButton(
                        icon: FaIcon(
                          FontAwesomeIcons.plusCircle,
                          color: PrimaryColor,
                        ),
                        onPressed: () {
                          setState(() {
                            custView = true;
                          });

//                        AddwalkinCustomer();
                        },
                      ),
                      Visibility(visible: custView, child: addCustomer())
                    ],
                  ),
                ),
              ),
              Divider(
                thickness: 2.0,
                color: PrimaryColor,
              ),
              Container(
                height: 30,
                child: ListTile(
                  title: Text("Total Bill"),
                  trailing: Text(
                    "${Rupees}${productData.totalAmount1.toString()}",
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 15.0,
                        color: PrimaryColor),
                  ),
                ),
              ),
              Container(
                height: 35,
                child: ListTile(
                  title: Text("Discount Amount"),
                  trailing: Container(
                    width: 100,
                    child: Row(
                      children: [
                        Padding(
                          padding: EdgeInsets.all(8.0),
                          child: Text(
                            "${Rupees}${discountprice.toStringAsFixed(2)}",
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 15.0,
                                color: PrimaryColor),
                          ),
                        ),
                        GestureDetector(
                          child: Padding(
                            padding: EdgeInsets.fromLTRB(0,5,8,5),
                            child: Icon(
                              Icons.edit,
                              color: PrimaryColor,
                            ),
                          ),
                          onTap: () {
                            setState(() {
                              showDialog<void>(
                                context: context,
                                barrierDismissible:
                                    false, // user must tap button!
                                builder: (BuildContext context) {
                                  return SingleChildScrollView(
                                    child: AlertDialog(
                                      title: Text('Enter Discount Price'),
                                      content: SingleChildScrollView(
                                        child: ListBody(
                                          children: <Widget>[
                                            TextField(
                                              autofocus: true,
                                              textAlign: TextAlign.left,
                                              keyboardType:
                                                  TextInputType.number,
                                              decoration: InputDecoration(
                                                  labelText: "Discount Price"),
                                              onChanged: (newText) {
                                                discountvalue =
                                                    int.parse(newText);
                                              },
                                            ),
                                          ],
                                        ),
                                      ),
                                      actions: <Widget>[
                                        TextButton(
                                          child: Text('Add'),
                                          onPressed: () {
                                            Navigator.of(context).pop();
                                            setState(() {
                                              discountprice = discountvalue;
                                              payableamount =
                                                  total_amount - discountprice;
                                            });
                                            // productData.updatePrice(updatedPrice,product);
                                          },
                                        ),
                                      ],
                                    ),
                                  );
                                },
                              );
                            });
                          },
                        )
                      ],
                    ),
                  ),
                ),
              ),
              Container(
                height: 30,
                child: ListTile(
                  title: Text("Payable Amount"),
                  trailing: Text(
                    "${Rupees}${payableamount.toString()}",
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 15.0,
                        color: PrimaryColor),
                  ),
                ),
              ),
              Container(
                height: 30,
                child: ListTile(
                  title: Text("Date"),
                  trailing: Text(
                    widget.DATE,
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 15.0,
                        color: PrimaryColor),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Divider(
                  thickness: 2.0,
                  color: PrimaryColor,
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(
                  "Amount: $Rupees${payableamount.toString()}",
                  style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 15.0,
                      color: PrimaryColor),
                ),
              ),
              Container(
                height: 30,
                child: Row(
                  children: [
                    Container(
                        child: Row(
                      children: [
                        Radio(
                          value: PaymentMode.cash,
                          groupValue: _paymode,
                          onChanged: (PaymentMode value) {
                            setState(() {
                              _paymode = value;
                              cashView = true;
                              debitView = false;
                              upiView = false;
                            });
                          },
                        ),
                        Text("Cash")
                      ],
                    )),
                    Container(
                        child: Row(
                      children: [
                        Radio(
                          value: PaymentMode.debit,
                          groupValue: _paymode,
                          onChanged: (PaymentMode value) {
                            setState(() {
                              _paymode = value;
                              cashView = false;
                              debitView = true;
                              upiView = false;
                              print(_paymode);
                            });
                          },
                        ),
                        Text("Card")
                      ],
                    )),
                    Container(
                        child: Row(
                      children: [
                        Radio(
                          value: PaymentMode.upi,
                          groupValue: _paymode,
                          onChanged: (PaymentMode value) {
                            setState(() {
                              _paymode = value;
                              cashView = false;
                              debitView = false;
                              upiView = true;
                            });
                          },
                        ),
                        Text("UPI")
                      ],
                    )),
                  ],
                ),
              ),
              Visibility(visible: cashView, child: cashWidget(payableamount)),
              Visibility(visible: debitView, child: debitWidget()),
              Visibility(visible: upiView, child: upiWidget()),
              Container(
                child: Row(
                  children: [
                    Expanded(
                      child: Material(
                        color: PrimaryColor,
                        borderRadius: BorderRadius.circular(30.0),
                        child: MaterialButton(
                          onPressed: () async {
//                          BillPrint();
                            int temp = productData.products.length;
                            print(temp);

                            for (int i = 0; i < temp; i++) {
                              ProductID.add(productData.products[i].pid);
                              ProductName.add(
                                  productData.products[i].productname);
                              RATE.add(productData.products[i].productprice);
                              Quant.add(productData.products[i].productquntity);
                              ProSubtotal.add(productData.products[i].subTotal);
                              GSTPER.add(productData.products[i].gstperce);
                            }

                            print(ProductName);
                            var MENUIDJOIN = ProductID.join("#");
                            var PRODUCTNAMEJOIN = ProductName.join("#");
                            var RATEJOIN = RATE.join("#");
                            var QUANTJOIN = Quant.join("#");
                            var SubJOIN = ProSubtotal.join("#");
                            var GSTPERJOIN = GSTPER.join("#");

                            print(MENUIDJOIN);
                            print(PRODUCTNAMEJOIN);
                            print(RATEJOIN);
                            print(SubJOIN);
                            print(QUANTJOIN);
                            print(widget.billingAmount);

                            setState(() {
                              if (_paymode == PaymentMode.cash) {
                                Paymentmode = "CASH";
                              } else if (_paymode == PaymentMode.debit) {
                                Paymentmode = "DEBIT";
                              } else {
                                Paymentmode = "UPI";
                              }
                            });

                            print(Paymentmode);
                            double tempstotal = productData.totalAmount1 -
                                productData.TotalGSTAmount;
                            String subtotal = tempstotal.toStringAsFixed(2);
                            var response = await salesInsert.insertPOSOrder(
                                "0",
                                Paymentmode,
                                "narration",
                                widget.DATE,
                                "dddd",
                                "1",
                                CustomerName,
                                "8408020559",
                                subtotal,
                                discountprice.toStringAsFixed(2),
                                payableamount.toStringAsFixed(2),
                                MENUIDJOIN,
                                QUANTJOIN,
                                RATEJOIN,
                                SubJOIN,
                                GSTPERJOIN);
                            print(response);
                            var resid = response["resid"];
                            print(resid);
                            if (resid == 200) {
                              productData.ClearTask();
                              Navigator.pop(context);
                              Fluttertoast.showToast(
                                  msg: "Bill genrated Sucessfully",
                                  toastLength: Toast.LENGTH_LONG,
                                  gravity: ToastGravity.CENTER,
                                  timeInSecForIosWeb: 1,
                                  backgroundColor: Colors.redAccent,
                                  textColor: Colors.white,
                                  fontSize: 16.0);
                            }

                            Navigator.of(context)
                                .push(MaterialPageRoute(builder: (_) {
                              return BillPrint(
                                  ProductName,
                                  RATE,
                                  Quant,
                                  ProSubtotal,
                                  GSTPER,
                                  subtotal,
                                  discountprice.toStringAsFixed(2),
                                  payableamount.toStringAsFixed(2),
                                  CustomerName,
                                  widget.DATE);
                            }));

                            // if (_paymode == PaymentMode.cash) {
                            //   Paymentmode = "CASH";
                            //   var result = await salesInsert.getpossalesinsert(
                            //     CustomerName,
                            //     widget.DATE,
                            //     PRODUCTNAMEJOIN,
                            //     RATEJOIN,
                            //     QUANTJOIN,
                            //     SubJOIN,
                            //     widget.billingAmount.toString(),
                            //     discountprice.toString(),
                            //     "30",
                            //     payableamount.toString(),
                            //     "0",
                            //     Paymentmode,
                            //     "0",
                            //     "0",
                            //     "0",
                            //     "0",
                            //     "0",
                            //     "0",
                            //     "0"
                            //   );
                            //   print(result);
                            //   var resid = result["resid"];
                            //   if (resid == 200) {
                            //     Navigator.pop(context);
                            //     productData.ClearTask();
                            //     Fluttertoast.showToast(
                            //         msg: "Bill generated successfully ",
                            //         toastLength: Toast.LENGTH_LONG,
                            //         gravity: ToastGravity.CENTER,
                            //         timeInSecForIosWeb: 1,
                            //         backgroundColor: PrimaryColor,
                            //         textColor: Colors.white,
                            //         fontSize: 16.0);
                            //   } else {
                            //     Fluttertoast.showToast(
                            //         msg: "Error. Try again ",
                            //         toastLength: Toast.LENGTH_LONG,
                            //         gravity: ToastGravity.CENTER,
                            //         timeInSecForIosWeb: 1,
                            //         backgroundColor: Colors.redAccent,
                            //         textColor: Colors.white,
                            //         fontSize: 16.0);
                            //   }
                            // } else if (_paymode == PaymentMode.debit) {
                            //   Paymentmode = "DEBIT";
                            //   var result = await salesInsert.getpossalesinsert(
                            //     CustomerName,
                            //     widget.DATE,
                            //     PRODUCTNAMEJOIN,
                            //     RATEJOIN,
                            //     QUANTJOIN,
                            //     SubJOIN,
                            //     widget.billingAmount.toString(),
                            //     discountprice.toString(),
                            //     "30",
                            //     payableamount.toString(),
                            //     "0",
                            //     Paymentmode,
                            //     "0",
                            //     CardName,
                            //     DebitCardOnName,
                            //     DebitCardNumber,
                            //     "0",
                            //     "0",
                            //     TypeCard
                            //   );
                            //   print(result);
                            //   var resid = result["resid"];
                            //   if (resid == 200) {
                            //     Navigator.pop(context);
                            //     productData.ClearTask();
                            //     Fluttertoast.showToast(
                            //         msg: "Bill generated successfully ",
                            //         toastLength: Toast.LENGTH_LONG,
                            //         gravity: ToastGravity.CENTER,
                            //         timeInSecForIosWeb: 1,
                            //         backgroundColor: PrimaryColor,
                            //         textColor: Colors.white,
                            //         fontSize: 16.0);
                            //   } else {
                            //     Fluttertoast.showToast(
                            //         msg: "Error. Try again ",
                            //         toastLength: Toast.LENGTH_LONG,
                            //         gravity: ToastGravity.CENTER,
                            //         timeInSecForIosWeb: 1,
                            //         backgroundColor: Colors.redAccent,
                            //         textColor: Colors.white,
                            //         fontSize: 16.0);
                            //   }
                            // } else {
                            //   Paymentmode = "UPI";
                            //   var result = await salesInsert.getpossalesinsert(
                            //     CustomerName,
                            //     widget.DATE,
                            //     PRODUCTNAMEJOIN,
                            //     RATEJOIN,
                            //     QUANTJOIN,
                            //     SubJOIN,
                            //     widget.billingAmount.toString(),
                            //     discountprice.toString(),
                            //     "30",
                            //     payableamount.toString(),
                            //     "",
                            //     Paymentmode,
                            //     "0",
                            //     "0",
                            //     "0",
                            //     "0",
                            //     UPIBankName,
                            //     UPITransactionId,
                            //     "0"
                            //   );
                            //   print(result);
                            //   var resid = result["resid"];
                            //   if (resid == 200) {
                            //     Navigator.pop(context);
                            //     productData.ClearTask();
                            //     Fluttertoast.showToast(
                            //         msg: "Bill generated successfully ",
                            //         toastLength: Toast.LENGTH_LONG,
                            //         gravity: ToastGravity.CENTER,
                            //         timeInSecForIosWeb: 1,
                            //         backgroundColor: PrimaryColor,
                            //         textColor: Colors.white,
                            //         fontSize: 16.0);
                            //   } else {
                            //     Fluttertoast.showToast(
                            //         msg: "Error. Try again ",
                            //         toastLength: Toast.LENGTH_LONG,
                            //         gravity: ToastGravity.CENTER,
                            //         timeInSecForIosWeb: 1,
                            //         backgroundColor: Colors.redAccent,
                            //         textColor: Colors.white,
                            //         fontSize: 16.0);
                            //   }
                            // }
                          },
                          minWidth: 100.0,
                          height: 35.0,
                          child: Text(
                            'Print',
                            style:
                                TextStyle(color: Colors.white, fontSize: 20.0),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 25.0,
                    ),
                    // Expanded(
                    //   child: Material(
                    //     color: PrimaryColor,
                    //     borderRadius: BorderRadius.circular(30.0),
                    //     child: MaterialButton(
                    //       onPressed: () {
                    //         // Navigator.of(context)
                    //         //     .push(MaterialPageRoute(builder: (_) {
                    //         //   return BillPrint();
                    //         // }));
                    //       },
                    //       minWidth: 100.0,
                    //       height: 35.0,
                    //       child: Text(
                    //         'Share',
                    //         style:
                    //             TextStyle(color: Colors.white, fontSize: 20.0),
                    //       ),
                    //     ),
                    //   ),
                    // ),
                    // SizedBox(
                    //   width: 25.0,
                    // ),
                    // Expanded(
                    //   child: Material(
                    //     color: PrimaryColor,
                    //     borderRadius: BorderRadius.circular(30.0),
                    //     child: MaterialButton(
                    //       onPressed: () {
                    //         Navigator.of(context)
                    //             .push(MaterialPageRoute(builder: (_) {
                    //           return BillPrint(ProductName,RATE,Quant,ProSubtotal,GSTPER);
                    //         }));
                    //
                    //       },
                    //       minWidth: 100.0,
                    //       height: 35.0,
                    //       child: Text(
                    //         'Print',
                    //         style:
                    //             TextStyle(color: Colors.white, fontSize: 20.0),
                    //       ),
                    //     ),
                    //   ),
                    // )
                  ],
                ),
              )
            ],
          ),
        ),
      );
    });
  }

  Widget debitWidget() {
    return Container(
      child: Row(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              width: MediaQuery.of(context).size.width * 0.20,
              child: DropdownSearch(
                isFilteredOnline: true,
                showClearButton: true,
                showSearchBox: true,
                items: [
                  "Debit Card",
                  "Credit Card",
                ],
                label: "Card",
                autoValidateMode: AutovalidateMode.onUserInteraction,
                onChanged: (value) {
                  setState(() {
                    TypeCard = value;
                    print(TypeCard);
                  });
                },
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              width: MediaQuery.of(context).size.width * 0.20,
              child: DropdownSearch(
                isFilteredOnline: true,
                showClearButton: true,
                showSearchBox: true,
                items: TypeCard == "Debit Card" ? DebitCards : CreditCards,
                label: "Card Type",
                autoValidateMode: AutovalidateMode.onUserInteraction,
                onChanged: (value) {
                  CardName = value;
                  print(CardName);
                },
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              width: MediaQuery.of(context).size.width * 0.20,
              child: TextField(
                keyboardType: TextInputType.number,
                onChanged: (value) {
                  DebitCardOnName = value;
                  print(DebitCardOnName);
                },
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'Name on card',
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              width: MediaQuery.of(context).size.width * 0.20,
              child: TextField(
                keyboardType: TextInputType.number,
                onChanged: (value) {
                  DebitCardNumber = value;
                  print(DebitCardNumber);
                },
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'Card No',
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget upiWidget() {
    return Container(
      child: Row(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              width: MediaQuery.of(context).size.width * 0.30,
              child: TextField(
                keyboardType: TextInputType.number,
                onChanged: (value) {
                  UPIBankName = value;
                  print(UPIBankName);
                },
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'Bank Name',
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              width: MediaQuery.of(context).size.width * 0.30,
              child: TextField(
                keyboardType: TextInputType.number,
                onChanged: (value) {
                  UPITransactionId = value;
                  print(UPITransactionId);
                },
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'Transaction Id',
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget cashWidget(double paymentamount) {
    double cashValue;
    double changeValue;
    TextEditingController textEditingControllerChange = TextEditingController();

    return Container(
      child: Row(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              width: MediaQuery.of(context).size.width * 0.20,
              child: TextField(
                keyboardType: TextInputType.number,
                onChanged: (value) {
                  cashValue = double.parse(value);
                  changeValue = cashValue - paymentamount;
                  if (changeValue < 0) {
                    textEditingControllerChange.text = 0.toString();
                  } else {
                    textEditingControllerChange.text = changeValue.toString();
                  }
                },
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'Cash',
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              width: MediaQuery.of(context).size.width * 0.20,
              child: TextField(
                keyboardType: TextInputType.number,
                controller: textEditingControllerChange,
                onChanged: (value) {},
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'Change',
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget addCustomer() {
    String CustomerNameTemp, CustomerMob;
    return Container(
      child: Row(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              width: MediaQuery.of(context).size.width * 0.25,
              child: TextField(
                keyboardType: TextInputType.text,
                onChanged: (value) {
                  CustomerName = value;
                },
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'Customer Name',
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              width: MediaQuery.of(context).size.width * 0.25,
              child: TextField(
                keyboardType: TextInputType.number,
                onChanged: (value) {
                  CustomerMob = value;
                },
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'Mobile N.o',
                ),
              ),
            ),
          ),
          GestureDetector(
            onTap: () async {
              if (CustomerName == null) {
                Fluttertoast.showToast(
                    msg: "Please Enter Customer Name",
                    toastLength: Toast.LENGTH_LONG,
                    gravity: ToastGravity.CENTER,
                    timeInSecForIosWeb: 1,
                    backgroundColor: PrimaryColor,
                    textColor: Colors.white,
                    fontSize: 16.0);
              }

              if (CustomerMob == null) {
                setState(() {
                  CustomerMob = "";
                });
              }

              var res = await walkinCustomer.sendWalkinData(
                  widget.DATE, CustomerNameTemp, CustomerMob);
              var resid = res["resid"];
              if (resid == 200) {
                Fluttertoast.showToast(
                    msg: "Customer Added Sucessfully",
                    toastLength: Toast.LENGTH_LONG,
                    gravity: ToastGravity.CENTER,
                    timeInSecForIosWeb: 1,
                    backgroundColor: PrimaryColor,
                    textColor: Colors.white,
                    fontSize: 16.0);
              } else {
                Fluttertoast.showToast(
                    msg: "Error",
                    toastLength: Toast.LENGTH_LONG,
                    gravity: ToastGravity.CENTER,
                    timeInSecForIosWeb: 1,
                    backgroundColor: Colors.redAccent,
                    textColor: Colors.white,
                    fontSize: 16.0);
              }

              setState(() {
                CustomerName = CustomerNameTemp;
              });

              print(res);
            },
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(
                'Add',
                style: TextStyle(
                    color: PrimaryColor,
                    fontSize: 20.0,
                    fontWeight: FontWeight.bold),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
