import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:retailerp/Adpater/fetch_POSbillList.dart';
import 'package:retailerp/Const/constcolor.dart';
import 'package:retailerp/POSUIONE/pos_billing_view.dart';
import 'package:retailerp/POSUIONE/pos_product_view.dart';
import 'package:retailerp/POSUITWO/pos_billing_view_two.dart';
import 'package:retailerp/POSUITWO/pos_product_view_two.dart';
import 'package:retailerp/utils/const.dart';

class POSFrontPage extends StatefulWidget {
  @override
  _POSFrontPageState createState() => _POSFrontPageState();
}


class _POSFrontPageState extends State<POSFrontPage> {

  POSBillList posBillList = new POSBillList();
  bool _checkBoxval = false;
  bool isSwitched = false;
  List<ServerBillList> salesbillingList = [];
  int TotalSales;
  String _selectdate = DateFormat('dd/MM/yyyy').format(new DateTime.now());

  List <bool> catgeorySelction = [
    false,
    false,
    false
  ];

  List <bool> subCatSelction = [
    false,
    false,
    false,
    false,
    false,
    false,
  ];


  Future<String> getBillList() async {
    var saleData = await posBillList.getBillList(_selectdate);
    var salesd = saleData["sales"];
    var totalSalesAmit = saleData["totalslesamt"];
    var resid = saleData["resid"];
    print(resid);
    List<ServerBillList> salesbill = [];
    for (var n in salesd) {
      ServerBillList pro = ServerBillList(n["SalesCustomername"], n["SalesTotalAmount"]);
      salesbill.add(pro);
    }
    setState(() {
      salesbillingList = salesbill;
      TotalSales = totalSalesAmit;
    });

  }


  @override
  void initState() {
    getBillList();
  }


  @override
  Widget build(BuildContext context) {
    DateTime now = DateTime.now();
    String formattedDate = DateFormat('kk:mm:ss  EEE d MMM').format(now);
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        endDrawer: Drawer(
          child: ListView(
            padding: EdgeInsets.zero,
            children: [
              Padding(
                padding: const EdgeInsets.only(top: 25.0),
                child: Container(
                  color: PrimaryColor,
                  child: ListTile(
                    title: Text("Today's Billing",style: TextStyle(color: Colors.white),),
                    subtitle: Text("Amount: $Rupees ${TotalSales.toString()}",style: TextStyle(color: Colors.white),),
                    trailing: Text("Date: $_selectdate",style: TextStyle(color: Colors.white)),
                  ),
                ),
              ),
              Container(
                height: 400,
                child: ListView.builder(
                    shrinkWrap: true,
                    itemCount: salesbillingList.length,
                    itemBuilder: (context, index) {
                    return  Padding(
                      padding: const EdgeInsets.only(bottom: 8.0),
                      child: Material(
                        elevation: 2,
                        child: Container(
                          child: ListTile(
                            title: Text('Customer Name: ${salesbillingList[index].CustomerName}'),
                            trailing: Text("Amount: $Rupees${salesbillingList[index].BillAmount}"),
                          ),
                        ),
                      ),
                    );
                }
                ),
              ),
            ],
          ),
        ),
        appBar: PreferredSize(
          preferredSize: new Size(65.0, 65.0),
          child: new AppBar(
              leading: IconButton(
                icon: Icon(Icons.arrow_back, color: Colors.white),
                onPressed: () => Navigator.of(context).pop(),
              ),
              actions: [
                Text("${formattedDate.toString()}",style: appBarTitleTextStyle,)
              ],
              title: Container(
                  margin:EdgeInsets.fromLTRB(0, 15, 0, 0),child: Text("POS",)),
              bottom: PreferredSize(
                preferredSize: new Size(50.0, 50.0),
                child: new Container(
                  width: 350.0,
                  child:  TabBar(
                      tabs: [
                        Container(
                            margin:EdgeInsets.fromLTRB(0, 0, 0, 6),
                            height: 30,
                            child: new Tab(text: 'POS 1')),
                        Container(
                            margin:EdgeInsets.fromLTRB(0, 0, 0, 6),
                            height:30,
                            child: new Tab(text: 'POS 2')),
//                      Container(
//                          height: 20,
//                          child: new Tab(text: '3')),
//                      Container(
//                          height: 20,
//                          child: new Tab(text: '4')),
//                      Container(
//                          height: 20,
//                          child: new Tab(text: '5')),
//                      Container(
//                          height: 20,
//                          child: new Tab(text: '6')),
//                      Container(
//                          height: 20,
//                          child: new Tab(text: '7')),
//                      Container(
//                          height: 20,
//                          child: new Tab(text: '8')),
                      ]
                  ),
                ),
              )
          ),
        ),
        body: TabBarView(
          children: [
            new SafeArea(
              child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: 10.0),
                  child: Row(
                    children: [
                      POSProductViewer(),
                      POSBillingView()
                    ],
                  )
              ),
            ),
            new SafeArea(
              child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: 10.0),
                  child: Row(
                    children: [
                      POSProductViewerTwo(),
                      POSBillingTwoView()
                    ],
                  )
              ),
            ),
//            SafeArea(
//              child: Padding(
//                  padding: EdgeInsets.symmetric(horizontal: 10.0),
//                  child: Row(
//                    children: [
//                       POSProductViewer(),
//                       POSBillingView()
//                    ],
//                  )
//              ),
//            ),
//            SafeArea(
//              child: Padding(
//                  padding: EdgeInsets.symmetric(horizontal: 10.0),
//                  child: Row(
//                    children: [
//                      POSProductViewer(),
//                      POSBillingView()
//                    ],
//                  )
//              ),
//            ),
//            SafeArea(
//              child: Padding(
//                  padding: EdgeInsets.symmetric(horizontal: 10.0),
//                  child: Row(
//                    children: [
//                      POSProductViewer(),
//                      POSBillingView()
//                    ],
//                  )
//              ),
//            ),
//            SafeArea(
//              child: Padding(
//                  padding: EdgeInsets.symmetric(horizontal: 10.0),
//                  child: Row(
//                    children: [
//                      POSProductViewer(),
//                      POSBillingView()
//                    ],
//                  )
//              ),
//            ),
//            SafeArea(
//              child: Padding(
//                  padding: EdgeInsets.symmetric(horizontal: 10.0),
//                  child: Row(
//                    children: [
//                      POSProductViewer(),
//                      POSBillingView()
//                    ],
//                  )
//              ),
//            ),
//            SafeArea(
//              child: Padding(
//                  padding: EdgeInsets.symmetric(horizontal: 10.0),
//                  child: Row(
//                    children: [
//                      POSProductViewer(),
//                      POSBillingView()
//                    ],
//                  )
//              ),
//            ),
          ],
        ),
      ),
    );
  }

}

class ServerBillList{

  String CustomerName;
  String BillAmount;

  ServerBillList(this.CustomerName,this.BillAmount);
}